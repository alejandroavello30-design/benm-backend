# BENM 0.3.0 — migración a Internet

La aplicación ya no muestra ni solicita la dirección del servidor al integrante. La URL se configura internamente en `MainActivity.kt` mediante `BENM_API_URL`.

## Arquitectura recomendada

- **LiveKit Cloud**: transporte de audio en tiempo real.
- **Backend BENM (Node/Express)**: códigos de equipo, emisión de tokens y alertas.
- **Android BENM**: solo nombre + código de equipo.

LiveKit recomienda generar los tokens desde un backend para producción; no se deben poner las claves API/secretas dentro de la aplicación. Ver documentación oficial: https://docs.livekit.io/frontends/build/authentication/endpoint/

## 1. Crear proyecto LiveKit Cloud

Crear un proyecto en LiveKit Cloud y obtener:

- LIVEKIT_URL (wss://...)
- LIVEKIT_API_KEY
- LIVEKIT_API_SECRET

No copies el API secret dentro de la app Android.

## 2. Hospedar `server/`

El servidor Node de esta carpeta debe ejecutarse en un servicio HTTPS con variables de entorno:

```env
PORT=3000
TEAM_ACCESS_CODE=CAMBIAR-ESTE-CODIGO
LIVEKIT_URL=wss://TU-PROYECTO.LIVEKIT.CLOUD
LIVEKIT_API_KEY=TU_KEY
LIVEKIT_API_SECRET=TU_SECRET
ROOM_MAX_PARTICIPANTS=25
```

El proveedor de hosting debe exponer HTTPS y mantener el proceso activo.

## 3. Conectar la aplicación

Después de obtener la URL HTTPS del backend, sustituir en:

`app/src/main/java/cl/radioequipo/app/MainActivity.kt`

```kotlin
private const val BENM_API_URL = "https://TU-BACKEND-BENM"
```

por la URL real.

## 4. Seguridad

Para producción se recomienda proteger el endpoint de tokens con autenticación propia. LiveKit documenta el endpoint de tokens como la alternativa de producción al servidor de desarrollo.

## Estado

Esta versión mantiene el servicio de primer plano para que el audio continúe funcionando con la pantalla bloqueada y en segundo plano.
