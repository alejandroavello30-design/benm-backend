package cl.radioequipo.app

import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.media.AudioManager
import android.os.Build
import android.os.IBinder
import androidx.core.app.NotificationCompat
import androidx.core.app.ServiceCompat
import androidx.core.content.ContextCompat
import com.twilio.audioswitch.AudioDevice
import io.livekit.android.audio.AudioSwitchHandler
import io.livekit.android.events.RoomEvent
import io.livekit.android.events.collect
import io.livekit.android.room.Room
import kotlinx.coroutines.*
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock

class RadioForegroundService : Service() {
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Main.immediate)
    private lateinit var room: Room
    private var connectionJob: Job? = null
    private var pollingJob: Job? = null
    private val microphoneMutex = Mutex()
    private var talking = false
    private var wanted = false
    private var connecting = false
    private var generation = 0
    private var speakerBefore = false
    private var config: Config? = null
    private var alerts: EmergencyNotifications? = null
    private val settings by lazy { getSharedPreferences("benm_radio_service", MODE_PRIVATE) }
    private data class Config(val backend: String, val channel: String, val name: String, val code: String, val recover: Boolean)

    override fun onCreate() {
        super.onCreate()
        instance = this
        speakerBefore = getSystemService(AudioManager::class.java)?.isSpeakerphoneOn == true
        room = RadioSession.room(applicationContext)
        getSystemService(NotificationManager::class.java).createNotificationChannel(NotificationChannel(CHANNEL_ID, "BENM activo", NotificationManager.IMPORTANCE_LOW).apply {
            description = "Radio y recepción de avisos mientras BENM está conectado"
            setShowBadge(false)
        })
        scope.launch {
            room.events.collect { event ->
                when (event) {
                    is RoomEvent.DataReceived -> if (wanted) EmergencyMessage.fromData(event.data, event.participant?.name ?: "Usuario")?.let {
                        config?.let { current -> alerts?.receive(it, current.name) }
                    }
                    is RoomEvent.Reconnecting -> if (wanted && !connecting) {
                        RadioSession.state.value = RadioSession.state.value.copy(phase = RadioPhase.RECONNECTING)
                        foreground("Reconectando radio y avisos…")
                    }
                    is RoomEvent.Reconnected -> if (wanted && !connecting) {
                        RadioSession.state.value = RadioSession.state.value.copy(phase = RadioPhase.CONNECTED, error = "")
                        foreground("Radio y avisos activos")
                    }
                    is RoomEvent.Disconnected -> if (wanted && !connecting && room.state == Room.State.DISCONNECTED) {
                        if (event.reason.toString() in setOf("DUPLICATE_IDENTITY", "PARTICIPANT_REMOVED", "ROOM_DELETED")) {
                            fail("La sesión fue cerrada o recuperada desde otra conexión.", RadioPhase.ERROR)
                        } else config?.let { connect(it.copy(recover = true), restoring = true) }
                    }
                    else -> Unit
                }
            }
        }
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == ACTION_STOP) { stop(this); return START_NOT_STICKY }
        val restoring = intent?.action != ACTION_CONNECT
        val current = if (!restoring) Config(
            intent?.getStringExtra("backend").orEmpty(), intent?.getStringExtra("channel").orEmpty(),
            intent?.getStringExtra("name").orEmpty(), intent?.getStringExtra("code").orEmpty(), intent?.getBooleanExtra("recover", false) ?: false
        ) else {
            if (!settings.getBoolean("enabled", false)) { stopSelf(); return START_NOT_STICKY }
            Config(settings.getString("backend", "").orEmpty(), settings.getString("channel", "general").orEmpty(),
                settings.getString("name", "").orEmpty(), settings.getString("code", "").orEmpty(), true)
        }
        if (current.name.isBlank() || current.code.isBlank() || current.backend != BACKEND || current.channel !in setOf("general", "coordinacion")) {
            fail("Vuelve a ingresar a BENM.", RadioPhase.ERROR); return START_NOT_STICKY
        }
        try { foreground(if (restoring) "Reconectando radio y avisos…" else "Conectando radio y avisos…") }
        catch (_: Exception) { fail("Android no permitió activar el servicio. Abre BENM y conecta nuevamente.", RadioPhase.ERROR); return START_NOT_STICKY }
        if (!wanted || !restoring) connect(current, restoring)
        return START_STICKY
    }

    private fun connect(current: Config, restoring: Boolean) {
        connectionJob?.cancel()
        val attempt = ++generation
        wanted = true
        config = current
        alerts = EmergencyNotifications(applicationContext, current.channel)
        RadioSession.state.value = RadioState(if (restoring) RadioPhase.RECONNECTING else RadioPhase.CONNECTING,
            current.name, current.channel, current.backend, attempt = System.nanoTime(), recovering = current.recover)
        connectionJob = scope.launch {
            var retry = restoring
            var wait = if (restoring) 3000L else 0L
            while (isActive && wanted && attempt == generation) {
                if (wait > 0) delay(wait)
                connecting = true
                try {
                    room.disconnect()
                    if (!retry) {
                        runCatching { withContext(Dispatchers.IO) { RadioApi.emergency(current.backend, current.channel) } }
                            .getOrNull()?.let { alerts?.baseline(it.id) }
                    }
                    val credentials = withContext(Dispatchers.IO) { RadioApi.token(current.backend, current.name, current.code, current.channel, current.recover || retry) }
                    room.connect(credentials.url, credentials.token)
                    room.localParticipant.setMicrophoneEnabled(false)
                    if (!wanted || attempt != generation) { room.disconnect(); return@launch }
                    getSharedPreferences("benm_login", MODE_PRIVATE).edit().putString("saved_name", current.name).putString("saved_code", current.code).apply()
                    settings.edit().putBoolean("enabled", true).putString("backend", current.backend).putString("channel", current.channel)
                        .putString("name", current.name).putString("code", current.code).apply()
                    RadioSession.state.value = RadioSession.state.value.copy(phase = RadioPhase.CONNECTED, role = credentials.role,
                        attendanceToken = credentials.attendanceToken, error = "")
                    foreground("Radio y avisos activos")
                    routeAudio()
                    startPolling()
                    return@launch
                } catch (error: CancellationException) { throw error }
                catch (error: Exception) {
                    room.disconnect()
                    val status = (error as? RadioApiException)?.status
                    if (status == 409) { fail(error.message.orEmpty(), RadioPhase.NAME_IN_USE); return@launch }
                    if (!restoring || status in setOf(400, 401, 403)) {
                        fail(error.message ?: "No se pudo conectar", RadioPhase.ERROR); return@launch
                    }
                    RadioSession.state.value = RadioSession.state.value.copy(phase = RadioPhase.RECONNECTING, error = "Sin conexión; reintentando…")
                    foreground("Sin conexión · Reintentando…")
                    retry = true
                    wait = (wait * 2).coerceIn(3000L, 60000L)
                } finally { connecting = false }
            }
        }
    }

    private fun routeAudio() {
        scope.launch {
            delay(300)
            val handler = room.audioHandler as? AudioSwitchHandler ?: return@launch
            val devices = handler.availableAudioDevices
            val preferred = devices.firstOrNull { it is AudioDevice.BluetoothHeadset }
                ?: devices.firstOrNull { it is AudioDevice.WiredHeadset }
                ?: devices.firstOrNull { it is AudioDevice.Speakerphone }
                ?: devices.firstOrNull { it is AudioDevice.Earpiece }
            if (wanted && preferred != null) {
                handler.selectDevice(preferred)
                if (preferred is AudioDevice.Speakerphone) runCatching { getSystemService(AudioManager::class.java)?.setSpeakerphoneOn(true) }
            }
        }
    }

    private fun startPolling() {
        pollingJob?.cancel()
        pollingJob = scope.launch {
            while (isActive && wanted) {
                val current = config ?: break
                try {
                    val alert = withContext(Dispatchers.IO) { RadioApi.emergency(current.backend, current.channel) }
                    if (wanted) alert?.let { alerts?.receive(it, current.name) }
                } catch (error: CancellationException) { throw error }
                catch (_: Exception) { /* The room event stream remains the primary delivery path. */ }
                delay(3000)
            }
        }
    }

    private fun setTalking(enabled: Boolean): Boolean {
        if (enabled && (!wanted || !RadioSession.uiVisible || room.state != Room.State.CONNECTED)) return false
        talking = enabled
        if (enabled) try { foreground("Transmitiendo…", microphone = true) } catch (_: Exception) { talking = false; return false }
        scope.launch {
            microphoneMutex.withLock {
                try {
                    room.localParticipant.setMicrophoneEnabled(talking && wanted && RadioSession.uiVisible)
                    if (!talking || !RadioSession.uiVisible) room.localParticipant.setMicrophoneEnabled(false)
                } catch (_: Exception) { talking = false }
                if (!talking && wanted) runCatching { foreground(if (RadioSession.state.value.phase == RadioPhase.CONNECTED) "Radio y avisos activos" else "Conectando radio y avisos…") }
            }
        }
        return true
    }

    private fun foreground(text: String, microphone: Boolean = false) {
        val open = PendingIntent.getActivity(this, 1001, Intent(this, MainActivity::class.java).apply {
            flags = Intent.FLAG_ACTIVITY_CLEAR_TOP or Intent.FLAG_ACTIVITY_SINGLE_TOP
        }, PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
        val stop = PendingIntent.getActivity(this, 1003, Intent(this, MainActivity::class.java).apply {
            action = "cl.radioequipo.app.CONFIRM_DISCONNECT"
            flags = Intent.FLAG_ACTIVITY_CLEAR_TOP or Intent.FLAG_ACTIVITY_SINGLE_TOP
            putExtra("confirm_disconnect", true)
        }, PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
        val notification = NotificationCompat.Builder(this, CHANNEL_ID).setSmallIcon(R.drawable.ic_notification)
            .setContentTitle("BENM · Radio y avisos").setContentText(text).setContentIntent(open).setOngoing(true)
            .setOnlyAlertOnce(true).setCategory(NotificationCompat.CATEGORY_SERVICE)
            .addAction(android.R.drawable.ic_media_pause, "DESCONECTAR", stop).build()
        val type = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PLAYBACK or
            (if (microphone && Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) ServiceInfo.FOREGROUND_SERVICE_TYPE_MICROPHONE else 0) else 0
        ServiceCompat.startForeground(this, NOTIFICATION_ID, notification, type)
    }

    private fun fail(message: String, phase: RadioPhase) {
        wanted = false
        settings.edit().clear().apply()
        pollingJob?.cancel()
        RadioSession.state.value = RadioSession.state.value.copy(phase = phase, attendanceToken = "", role = "member", error = message)
        stopForeground(STOP_FOREGROUND_REMOVE)
        stopSelf()
    }

    override fun onTaskRemoved(rootIntent: Intent?) {
        setTalking(false) // Closing the screen never keeps the microphone open.
        super.onTaskRemoved(rootIntent) // Keep the explicitly started radio service alive.
    }
    override fun onDestroy() {
        val unexpected = wanted
        talking = false
        scope.cancel()
        room.disconnect()
        if (unexpected) RadioSession.state.value = RadioSession.state.value.copy(phase = RadioPhase.RECONNECTING)
        runCatching { getSystemService(AudioManager::class.java)?.setSpeakerphoneOn(speakerBefore) }
        if (instance === this) instance = null
        super.onDestroy()
    }
    override fun onBind(intent: Intent?): IBinder? = null

    companion object {
        const val CHANNEL_ID = "radio_equipo_active"
        const val NOTIFICATION_ID = 1001
        const val ACTION_STOP = "cl.radioequipo.app.STOP_RADIO_SERVICE"
        private const val ACTION_CONNECT = "cl.radioequipo.app.CONNECT_RADIO"
        private const val ACTION_RESUME = "cl.radioequipo.app.RESUME_RADIO"
        private const val BACKEND = "https://benm-backend.onrender.com"
        private var instance: RadioForegroundService? = null
        fun connect(context: Context, name: String, code: String, channel: String, recover: Boolean) {
            RadioSession.pendingAlert.value = null
            context.getSystemService(NotificationManager::class.java).cancel(2202)
            ContextCompat.startForegroundService(context, Intent(context, RadioForegroundService::class.java).setAction(ACTION_CONNECT)
                .putExtra("backend", BACKEND).putExtra("name", name).putExtra("code", code).putExtra("channel", channel).putExtra("recover", recover))
        }
        fun resumeIfEnabled(context: Context) {
            if (instance == null && context.getSharedPreferences("benm_radio_service", Context.MODE_PRIVATE).getBoolean("enabled", false))
                ContextCompat.startForegroundService(context, Intent(context, RadioForegroundService::class.java).setAction(ACTION_RESUME))
        }
        fun stop(context: Context) {
            instance?.wanted = false
            instance?.generation = (instance?.generation ?: 0) + 1
            context.getSharedPreferences("benm_radio_service", Context.MODE_PRIVATE).edit().clear().apply()
            context.stopService(Intent(context, RadioForegroundService::class.java))
            RadioSession.pendingAlert.value = null
            context.getSystemService(NotificationManager::class.java).cancel(2202)
            RadioSession.state.value = RadioState()
        }
        fun talk(enabled: Boolean): Boolean = instance?.setTalking(enabled) ?: false
    }
}
