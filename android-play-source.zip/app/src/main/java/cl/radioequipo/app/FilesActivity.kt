package cl.radioequipo.app

import android.app.Activity
import android.content.Intent
import android.graphics.BitmapFactory
import android.graphics.Color
import android.graphics.drawable.GradientDrawable
import android.graphics.pdf.PdfRenderer
import android.net.Uri
import android.os.Bundle
import android.os.ParcelFileDescriptor
import androidx.core.content.FileProvider
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import android.provider.OpenableColumns
import android.view.Gravity
import android.view.View
import android.widget.Button
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import org.json.JSONArray
import java.io.File
import java.io.FileOutputStream
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder
import java.util.Locale
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

class FilesActivity : Activity() {

    private lateinit var list: LinearLayout
    private lateinit var addButton: Button
    private val pickRequest = 9101

    private val backendUrl by lazy {
        intent.getStringExtra("backendUrl").orEmpty().trimEnd('/').ifBlank { "https://benm-backend.onrender.com" }
    }
    private val accessCode by lazy { intent.getStringExtra("accessCode").orEmpty() }
    private val role by lazy { intent.getStringExtra("userRole").orEmpty().ifBlank { "member" } }
    private val isAdmin get() = role == "admin"
    private var showingViewer = false

    private data class RemoteFile(
        val id: String,
        val name: String,
        val size: Long,
        val modified: Long,
        val extension: String
    )

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        title = "Instructivos BENM"
        setContentView(buildLibraryRoot())
        refreshList()
    }

    private fun buildLibraryRoot(): View {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(14, 14, 14, 8)
            setBackgroundColor(Color.rgb(10, 18, 28))
        }

        val header = TextView(this).apply {
            text = "📚  INSTRUCTIVOS"
            textSize = 24f
            setTextColor(Color.WHITE)
            setTypeface(typeface, android.graphics.Typeface.BOLD)
        }
        root.addView(header)

        val info = TextView(this).apply {
            text = if (isAdmin) {
                "REPOSITORIO DEL EQUIPO · ADMINISTRADOR\nPuedes subir y eliminar archivos."
            } else {
                "REPOSITORIO DEL EQUIPO · SOLO LECTURA\nPuedes consultar y abrir los instructivos."
            }
            textSize = 12f
            setTextColor(Color.LTGRAY)
            setPadding(0, 5, 0, 8)
        }
        root.addView(info)

        addButton = Button(this).apply {
            text = "＋  SUBIR ARCHIVO"
            textSize = 14f
            isAllCaps = false
            setTextColor(Color.WHITE)
            setPadding(12, 0, 12, 0)
            background = roundedButton(Color.rgb(24, 105, 190))
            setOnClickListener { pickFile() }
        }
        if (isAdmin) root.addView(addButton, LinearLayout.LayoutParams(-1, 48))

        val scrollContent = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(0, 4, 0, 8)
        }
        list = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
        }
        scrollContent.addView(list, LinearLayout.LayoutParams(-1, -2))

        val back = Button(this).apply {
            text = "‹  VOLVER A BENM"
            textSize = 14f
            isAllCaps = false
            setTextColor(Color.WHITE)
            background = roundedButton(Color.rgb(45, 62, 80))
            setOnClickListener { finish() }
        }
        val backParams = LinearLayout.LayoutParams(-1, 50).apply {
            topMargin = 12
            bottomMargin = 8
        }
        scrollContent.addView(back, backParams)

        val scroll = ScrollView(this).apply {
            isFillViewport = false
            clipToPadding = false
            addView(scrollContent, FrameLayout.LayoutParams(-1, -2))
        }
        root.addView(scroll, LinearLayout.LayoutParams(-1, 0, 1f).apply { topMargin = 6 })

        ViewCompat.setOnApplyWindowInsetsListener(root) { view, insets ->
            val bars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            view.setPadding(14 + bars.left, 14 + bars.top, 14 + bars.right, 10 + bars.bottom)
            insets
        }
        ViewCompat.requestApplyInsets(root)
        return root
    }

    private fun pickFile() {
        if (!isAdmin) {
            toast("Solo el administrador puede subir archivos")
            return
        }
        val intent = Intent(Intent.ACTION_OPEN_DOCUMENT).apply {
            addCategory(Intent.CATEGORY_OPENABLE)
            type = "*/*"
        }
        startActivityForResult(intent, pickRequest)
    }

    @Deprecated("Android activity result API kept simple for this project")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode != pickRequest || resultCode != RESULT_OK) return
        val uri = data?.data ?: return

        CoroutineScope(Dispatchers.Main).launch {
            try {
                setBusy(true)
                uploadFile(uri)
                toast("Archivo subido al repositorio")
                refreshList()
            } catch (e: Exception) {
                toast(e.message ?: "No se pudo subir el archivo")
            } finally {
                setBusy(false)
            }
        }
    }

    private suspend fun uploadFile(uri: Uri) = withContext(Dispatchers.IO) {
        val displayName = queryDisplayName(uri) ?: "archivo_${System.currentTimeMillis()}"
        val connection = (URL("$backendUrl/files").openConnection() as HttpURLConnection).apply {
            requestMethod = "POST"
            doOutput = true
            connectTimeout = 15_000
            readTimeout = 60_000
            setRequestProperty("Accept", "application/json")
        }

        val boundary = "----BENM${System.currentTimeMillis()}"
        connection.setRequestProperty("Content-Type", "multipart/form-data; boundary=$boundary")

        try {
            val output = connection.outputStream
            output.write("--$boundary\r\n".toByteArray(Charsets.UTF_8))
            output.write("Content-Disposition: form-data; name=\"accessCode\"\r\n\r\n".toByteArray(Charsets.UTF_8))
            output.write(accessCode.toByteArray(Charsets.UTF_8))
            output.write("\r\n".toByteArray(Charsets.UTF_8))

            output.write("--$boundary\r\n".toByteArray(Charsets.UTF_8))
            output.write("Content-Disposition: form-data; name=\"file\"; filename=\"${escapeMultipartName(displayName)}\"\r\n".toByteArray())
            output.write("Content-Type: ${guessMime(displayName)}\r\n\r\n".toByteArray())

            contentResolver.openInputStream(uri).use { input ->
                requireNotNull(input) { "No se pudo leer el archivo seleccionado" }
                input.copyTo(output, 16 * 1024)
            }
            output.write("\r\n--$boundary--\r\n".toByteArray())
            output.flush()
            output.close()

            val status = connection.responseCode
            val body = readResponse(connection, status)
            if (status !in 200..299) {
                throw IllegalStateException(parseError(body) ?: "El servidor rechazó el archivo ($status)")
            }
        } finally {
            connection.disconnect()
        }
    }

    private fun refreshList() {
        CoroutineScope(Dispatchers.Main).launch {
            try {
                val files = withContext(Dispatchers.IO) { fetchFiles() }
                renderFiles(files)
            } catch (e: Exception) {
                renderError(e.message ?: "No se pudieron cargar los instructivos")
            }
        }
    }

    private suspend fun fetchFiles(): List<RemoteFile> = withContext(Dispatchers.IO) {
        val url = URL("$backendUrl/files?accessCode=${URLEncoder.encode(accessCode, "UTF-8")}")
        val connection = (url.openConnection() as HttpURLConnection).apply {
            requestMethod = "GET"
            connectTimeout = 10_000
            readTimeout = 15_000
            setRequestProperty("Accept", "application/json")
        }
        try {
            val status = connection.responseCode
            val body = readResponse(connection, status)
            if (status !in 200..299) {
                throw IllegalStateException(parseError(body) ?: "No se pudieron cargar los archivos ($status)")
            }
            val array = JSONArray(org.json.JSONObject(body).optString("files", "[]"))
            buildList {
                for (i in 0 until array.length()) {
                    val o = array.getJSONObject(i)
                    add(
                        RemoteFile(
                            o.getString("id"),
                            o.getString("name"),
                            o.optLong("size"),
                            o.optLong("modified"),
                            o.optString("extension", "ARCHIVO")
                        )
                    )
                }
            }
        } finally {
            connection.disconnect()
        }
    }

    private fun renderFiles(files: List<RemoteFile>) {
        list.removeAllViews()
        if (files.isEmpty()) {
            val empty = TextView(this).apply {
                text = if (isAdmin) {
                    "Todavía no hay instructivos.\n\nPulsa SUBIR ARCHIVO para agregar el primero."
                } else {
                    "Todavía no hay instructivos disponibles."
                }
                textSize = 15f
                setTextColor(Color.LTGRAY)
                gravity = Gravity.CENTER
                setPadding(20, 40, 20, 40)
            }
            list.addView(empty, LinearLayout.LayoutParams(-1, 180))
            return
        }

        // Vista tipo miniaturas: dos archivos por fila para aprovechar mejor la pantalla.
        files.chunked(2).forEach { rowFiles ->
            val row = LinearLayout(this).apply {
                orientation = LinearLayout.HORIZONTAL
            }
            rowFiles.forEach { file ->
                row.addView(buildFileThumbnail(file), LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f).apply {
                    setMargins(4, 4, 4, 4)
                })
            }
            if (rowFiles.size == 1) {
                row.addView(View(this), LinearLayout.LayoutParams(0, 1, 1f).apply { setMargins(4, 4, 4, 4) })
            }
            list.addView(row, LinearLayout.LayoutParams(-1, -2))
        }
    }

    private fun buildFileThumbnail(file: RemoteFile): View {
        val card = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER_HORIZONTAL
            setPadding(8, 10, 8, 9)
            background = roundedButton(Color.rgb(23, 37, 51))
            elevation = 2f
        }

        val thumb = FrameLayout(this).apply {
            background = roundedButton(thumbnailColor(file.extension))
        }
        val thumbIcon = TextView(this).apply {
            text = iconFor(file.extension)
            textSize = 34f
            gravity = Gravity.CENTER
            setTextColor(Color.WHITE)
        }
        thumb.addView(thumbIcon, FrameLayout.LayoutParams(-1, -1))
        val ext = TextView(this).apply {
            text = file.extension.take(5)
            textSize = 9f
            setTextColor(Color.WHITE)
            gravity = Gravity.CENTER
            setTypeface(typeface, android.graphics.Typeface.BOLD)
            background = roundedButton(0x99000000.toInt())
            setPadding(5, 1, 5, 1)
        }
        thumb.addView(ext, FrameLayout.LayoutParams(-2, 24, Gravity.BOTTOM or Gravity.END).apply { setMargins(0, 0, 4, 4) })
        card.addView(thumb, LinearLayout.LayoutParams(-1, dp(92)))

        val name = TextView(this).apply {
            text = file.name
            textSize = 13f
            setTextColor(Color.WHITE)
            gravity = Gravity.CENTER
            maxLines = 2
            ellipsize = android.text.TextUtils.TruncateAt.END
            setPadding(2, 8, 2, 1)
        }
        card.addView(name, LinearLayout.LayoutParams(-1, 48))

        val size = TextView(this).apply {
            text = formatSize(file.size)
            textSize = 10f
            setTextColor(Color.LTGRAY)
            gravity = Gravity.CENTER
        }
        card.addView(size, LinearLayout.LayoutParams(-1, 22))

        val open = Button(this).apply {
            text = "VER / ABRIR"
            textSize = 11f
            isAllCaps = false
            minHeight = dp(42)
            setTextColor(Color.WHITE)
            setPadding(4, 0, 4, 0)
            background = roundedButton(Color.rgb(24, 105, 190))
            setOnClickListener { downloadAndOpen(file) }
        }
        card.addView(open, LinearLayout.LayoutParams(-1, 44).apply { topMargin = 5 })

        if (isAdmin) {
            val delete = Button(this).apply {
                text = "ELIMINAR"
                textSize = 10f
                isAllCaps = false
                minHeight = dp(38)
                setTextColor(Color.WHITE)
                setPadding(4, 0, 4, 0)
                background = roundedButton(Color.rgb(175, 45, 55))
                setOnClickListener { confirmDelete(file) }
            }
            card.addView(delete, LinearLayout.LayoutParams(-1, 40).apply { topMargin = 5 })
        }
        return card
    }

    private fun thumbnailColor(extension: String): Int = when (extension.lowercase(Locale.ROOT)) {
        "pdf" -> Color.rgb(190, 48, 55)
        "png", "jpg", "jpeg", "webp" -> Color.rgb(35, 125, 175)
        "doc", "docx" -> Color.rgb(45, 90, 175)
        "xls", "xlsx" -> Color.rgb(35, 135, 90)
        "ppt", "pptx" -> Color.rgb(210, 100, 35)
        "txt", "md", "csv", "log", "json", "xml", "html", "htm" -> Color.rgb(95, 105, 120)
        else -> Color.rgb(85, 70, 140)
    }

    private fun dp(value: Int): Int = (value * resources.displayMetrics.density).toInt()

    private fun renderError(message: String) {
        list.removeAllViews()
        val error = TextView(this).apply {
            this.text = "No se pudieron cargar los instructivos.\n\n$message\n\nToca aquí para intentar nuevamente."
            textSize = 14f
            setTextColor(Color.LTGRAY)
            gravity = Gravity.CENTER
            setPadding(20, 30, 20, 30)
            setOnClickListener { refreshList() }
        }
        list.addView(error, LinearLayout.LayoutParams(-1, -1))
    }

    private fun confirmDelete(file: RemoteFile) {
        android.app.AlertDialog.Builder(this)
            .setTitle("Eliminar archivo")
            .setMessage("¿Eliminar \"${file.name}\" del repositorio del equipo?")
            .setNegativeButton("CANCELAR", null)
            .setPositiveButton("ELIMINAR") { _, _ ->
                CoroutineScope(Dispatchers.Main).launch {
                    try {
                        setBusy(true)
                        deleteRemoteFile(file.id)
                        toast("Archivo eliminado")
                        refreshList()
                    } catch (e: Exception) {
                        toast(e.message ?: "No se pudo eliminar")
                    } finally {
                        setBusy(false)
                    }
                }
            }
            .show()
    }

    private suspend fun deleteRemoteFile(id: String) = withContext(Dispatchers.IO) {
        val url = URL("$backendUrl/files/${Uri.encode(id)}?accessCode=${URLEncoder.encode(accessCode, "UTF-8")}")
        val connection = (url.openConnection() as HttpURLConnection).apply {
            requestMethod = "DELETE"
            connectTimeout = 10_000
            readTimeout = 15_000
        }
        try {
            val status = connection.responseCode
            val body = readResponse(connection, status)
            if (status !in 200..299) {
                throw IllegalStateException(parseError(body) ?: "No se pudo eliminar ($status)")
            }
        } finally {
            connection.disconnect()
        }
    }

    private fun downloadAndOpen(file: RemoteFile) {
        CoroutineScope(Dispatchers.Main).launch {
            try {
                setBusy(true)
                val local = withContext(Dispatchers.IO) { downloadToCache(file.id, file.name) }
                openFile(local)
            } catch (e: Exception) {
                toast(e.message ?: "No se pudo abrir el archivo")
            } finally {
                setBusy(false)
            }
        }
    }

    private suspend fun downloadToCache(id: String, displayName: String): File = withContext(Dispatchers.IO) {
        val url = URL("$backendUrl/files/${Uri.encode(id)}?accessCode=${URLEncoder.encode(accessCode, "UTF-8")}")
        val connection = (url.openConnection() as HttpURLConnection).apply {
            requestMethod = "GET"
            connectTimeout = 10_000
            readTimeout = 60_000
        }
        try {
            val status = connection.responseCode
            if (status !in 200..299) {
                val body = readResponse(connection, status)
                throw IllegalStateException(parseError(body) ?: "No se pudo descargar ($status)")
            }
            val local = File(cacheDir, "benm_${System.currentTimeMillis()}_${safeLocalName(displayName)}")
            connection.inputStream.use { input ->
                FileOutputStream(local).use { output -> input.copyTo(output, 16 * 1024) }
            }
            local
        } finally {
            connection.disconnect()
        }
    }

    private fun openFile(file: File) {
        when {
            file.extension.equals("pdf", true) -> showPdf(file)
            file.extension.lowercase(Locale.ROOT) in setOf("png", "jpg", "jpeg", "webp") -> showImage(file)
            file.extension.lowercase(Locale.ROOT) in setOf("txt", "csv", "log", "md", "json", "xml", "html", "htm") -> showText(file)
            else -> openWithExternalApp(file)
        }
    }

    private fun openWithExternalApp(file: File) {
        try {
            val uri = FileProvider.getUriForFile(this, "$packageName.fileprovider", file)
            val mime = guessMime(file.name)
            val intent = Intent(Intent.ACTION_VIEW).apply {
                setDataAndType(uri, mime)
                addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            }
            startActivity(intent)
        } catch (_: android.content.ActivityNotFoundException) {
            toast("No hay una aplicación instalada para abrir ${file.extension.uppercase(Locale.ROOT)}")
        } catch (e: Exception) {
            toast("No se pudo abrir el archivo: ${e.message ?: "error desconocido"}")
        }
    }

    private fun showPdf(file: File) {
        runCatching {
            val fd = ParcelFileDescriptor.open(file, ParcelFileDescriptor.MODE_READ_ONLY)
            val renderer = PdfRenderer(fd)
            if (renderer.pageCount == 0) throw IllegalStateException("PDF sin páginas")
            val pageCount = renderer.pageCount
            val page = renderer.openPage(0)
            val bitmap = android.graphics.Bitmap.createBitmap(page.width * 2, page.height * 2, android.graphics.Bitmap.Config.ARGB_8888)
            page.render(bitmap, null, null, PdfRenderer.Page.RENDER_MODE_FOR_DISPLAY)
            page.close()
            renderer.close()
            fd.close()
            showBitmapViewer(file.name, bitmap, "Página 1 de $pageCount")
        }.onFailure { toast("No se pudo abrir el PDF: ${it.message}") }
    }

    private fun showImage(file: File) {
        val bitmap = BitmapFactory.decodeFile(file.absolutePath)
        if (bitmap == null) {
            toast("No se pudo abrir la imagen")
            return
        }
        showBitmapViewer(file.name, bitmap, "Imagen")
    }

    private fun showBitmapViewer(title: String, bitmap: android.graphics.Bitmap, subtitle: String) {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(14, 14, 14, 14)
            setBackgroundColor(Color.BLACK)
        }
        val top = TextView(this).apply {
            this.text = "$title\n$subtitle"
            textSize = 15f
            setTextColor(Color.WHITE)
            setPadding(58, 8, 0, 8)
        }
        val image = ImageView(this).apply {
            setImageBitmap(bitmap)
            adjustViewBounds = true
            scaleType = ImageView.ScaleType.FIT_CENTER
        }
        root.addView(top, LinearLayout.LayoutParams(-1, -2))
        root.addView(image, LinearLayout.LayoutParams(-1, 0, 1f))
        setViewerContent(root)
    }

    private fun showText(file: File) {
        val text = runCatching { file.readText(Charsets.UTF_8) }.getOrElse { "No se pudo leer el documento." }
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(16, 16, 16, 16)
            setBackgroundColor(Color.rgb(10, 18, 28))
        }
        val title = TextView(this).apply {
            this.text = file.name
            textSize = 19f
            setTextColor(Color.WHITE)
        }
        val body = TextView(this).apply {
            this.text = text
            textSize = 14f
            setTextColor(Color.WHITE)
            setPadding(0, 12, 0, 12)
            setTextIsSelectable(true)
        }
        val scroll = android.widget.ScrollView(this).apply { addView(body) }
        title.setPadding(58, 8, 0, 8)
        root.addView(title)
        root.addView(scroll, LinearLayout.LayoutParams(-1, 0, 1f))
        setViewerContent(root)
    }

    private fun setViewerContent(content: View) {
        val frame = FrameLayout(this).apply {
            setBackgroundColor(Color.rgb(10, 18, 28))
        }
        frame.addView(content, FrameLayout.LayoutParams(-1, -1))

        val back = TextView(this).apply {
            text = "‹"
            textSize = 38f
            gravity = Gravity.CENTER
            setTextColor(Color.WHITE)
            setTypeface(typeface, android.graphics.Typeface.BOLD)
            background = GradientDrawable().apply {
                shape = GradientDrawable.OVAL
                setColor(0xDD1B2B3A.toInt())
                setStroke(2, 0xFFFFFFFF.toInt())
            }
            elevation = 18f
            contentDescription = "Volver a instructivos"
            setOnClickListener {
                onBackPressed()
            }
        }
        val size = (52 * resources.displayMetrics.density).toInt()
        val margin = (10 * resources.displayMetrics.density).toInt()
        val params = FrameLayout.LayoutParams(size, size, Gravity.TOP or Gravity.START).apply {
            leftMargin = margin
            topMargin = margin
        }
        frame.addView(back, params)

        ViewCompat.setOnApplyWindowInsetsListener(frame) { _, insets ->
            val bars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            params.topMargin = margin + bars.top
            back.layoutParams = params
            insets
        }
        showingViewer = true
        setContentView(frame)
        ViewCompat.requestApplyInsets(frame)
    }

    @Deprecated("Use OnBackInvokedDispatcher on newer Android; kept for compatibility")
    override fun onBackPressed() {
        if (showingViewer) {
            showingViewer = false
            setContentView(buildLibraryRoot())
            refreshList()
        } else {
            super.onBackPressed()
        }
    }

    private fun queryDisplayName(uri: Uri): String? {
        contentResolver.query(uri, arrayOf(OpenableColumns.DISPLAY_NAME), null, null, null)?.use { c ->
            if (c.moveToFirst()) return c.getString(0)
        }
        return null
    }

    private fun setBusy(busy: Boolean) {
        addButton.isEnabled = !busy
        if (busy) toast("Procesando archivo...")
    }

    private fun readResponse(connection: HttpURLConnection, status: Int): String {
        val stream = if (status in 200..299) connection.inputStream else connection.errorStream
        return stream?.bufferedReader(Charsets.UTF_8)?.use { it.readText() }.orEmpty()
    }

    private fun parseError(body: String): String? =
        runCatching { org.json.JSONObject(body).optString("error").ifBlank { null } }.getOrNull()

    private fun escapeMultipartName(name: String): String =
        name.replace("\\", "_").replace("\"", "_").replace("\r", "_").replace("\n", "_")

    private fun safeLocalName(name: String): String =
        name.replace(Regex("[^A-Za-z0-9._-]"), "_").take(120)

    private fun guessMime(name: String): String = when (name.substringAfterLast('.', "").lowercase(Locale.ROOT)) {
        "pdf" -> "application/pdf"
        "png" -> "image/png"
        "jpg", "jpeg" -> "image/jpeg"
        "webp" -> "image/webp"
        "txt" -> "text/plain"
        "csv" -> "text/csv"
        "json" -> "application/json"
        "xml" -> "application/xml"
        "html", "htm" -> "text/html"
        "doc" -> "application/msword"
        "docx" -> "application/vnd.openxmlformats-officedocument.wordprocessingml.document"
        "xls" -> "application/vnd.ms-excel"
        "xlsx" -> "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet"
        "ppt" -> "application/vnd.ms-powerpoint"
        "pptx" -> "application/vnd.openxmlformats-officedocument.presentationml.presentation"
        else -> "application/octet-stream"
    }

    private fun iconFor(extension: String): String = when (extension.lowercase(Locale.ROOT)) {
        "pdf" -> "📄"
        "png", "jpg", "jpeg", "webp" -> "🖼️"
        "txt", "md", "csv", "log", "json", "xml", "html", "htm" -> "📝"
        "doc", "docx" -> "📘"
        "xls", "xlsx" -> "📊"
        "ppt", "pptx" -> "📙"
        else -> "📎"
    }

    private fun roundedButton(color: Int): GradientDrawable =
        GradientDrawable().apply {
            setColor(color)
            cornerRadius = 14f * resources.displayMetrics.density
        }

    private fun formatSize(bytes: Long): String = when {
        bytes < 1024 -> "$bytes B"
        bytes < 1024 * 1024 -> "${bytes / 1024} KB"
        else -> "${bytes / (1024 * 1024)} MB"
    }

    private fun toast(message: String) = Toast.makeText(this, message, Toast.LENGTH_SHORT).show()
}
