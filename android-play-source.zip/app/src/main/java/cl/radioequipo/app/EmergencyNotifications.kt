package cl.radioequipo.app

import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.media.AudioAttributes
import android.media.RingtoneManager
import android.os.Build
import androidx.core.app.NotificationCompat
import org.json.JSONArray

class EmergencyNotifications(private val context: Context, channel: String) {
    private val prefs = context.getSharedPreferences("benm_emergency_seen", Context.MODE_PRIVATE)
    private val key = "ids_$channel"
    private val ledger = AlertLedger(runCatching {
        val array = JSONArray(prefs.getString(key, "[]"))
        List(array.length()) { array.getString(it) }
    }.getOrDefault(emptyList()))
    private fun persist() { prefs.edit().putString(key, JSONArray(ledger.snapshot()).toString()).apply() }
    fun baseline(id: String) { ledger.seed(id); persist() }
    fun receive(alert: EmergencyMessage, self: String) {
        val deliver = ledger.accept(alert.id, alert.sender, self)
        persist()
        if (!deliver) return
        RadioSession.pendingAlert.value = alert
        val manager = context.getSystemService(NotificationManager::class.java)
        val id = "emergency_alerts_v5"
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) manager.createNotificationChannel(NotificationChannel(id, "Emergencias BENM", NotificationManager.IMPORTANCE_HIGH).apply {
            description = "Alertas urgentes del equipo BENM"
            enableVibration(true)
            vibrationPattern = longArrayOf(0, 500, 250, 500, 250, 900)
            setSound(RingtoneManager.getDefaultUri(RingtoneManager.TYPE_ALARM), AudioAttributes.Builder().setUsage(AudioAttributes.USAGE_ALARM).build())
        })
        val open = Intent(context, EmergencyAlertActivity::class.java).apply {
            flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP or Intent.FLAG_ACTIVITY_SINGLE_TOP
            putExtra(EmergencyAlertActivity.EXTRA_SENDER, alert.sender)
            putExtra(EmergencyAlertActivity.EXTRA_TYPE, alert.type)
            putExtra(EmergencyAlertActivity.EXTRA_MESSAGE, alert.message)
            putExtra("alert_id", alert.id)
        }
        val action = PendingIntent.getActivity(context, alert.id.hashCode(), open, PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
        val notification = NotificationCompat.Builder(context, id).setSmallIcon(R.drawable.ic_notification)
            .setContentTitle("🚨 ${alert.type} · BENM").setContentText("${alert.sender}: ${alert.message}")
            .setStyle(NotificationCompat.BigTextStyle().bigText("${alert.type}\n${alert.message}\nActivada por: ${alert.sender}"))
            .setPriority(NotificationCompat.PRIORITY_MAX).setCategory(NotificationCompat.CATEGORY_ALARM)
            .setVisibility(NotificationCompat.VISIBILITY_PUBLIC).setContentIntent(action).setAutoCancel(true).build()
        runCatching { manager.notify(2202, notification) }
    }
}
