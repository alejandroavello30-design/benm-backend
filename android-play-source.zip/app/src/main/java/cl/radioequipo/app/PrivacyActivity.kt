package cl.radioequipo.app

import android.os.Bundle
import android.text.Html
import android.text.method.LinkMovementMethod
import android.widget.Button
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import androidx.activity.ComponentActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat

class PrivacyActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(0xFF07121D.toInt())
        }
        val spacing = (16 * resources.displayMetrics.density).toInt()
        ViewCompat.setOnApplyWindowInsetsListener(root) { view, insets ->
            val bars = insets.getInsets(WindowInsetsCompat.Type.systemBars() or WindowInsetsCompat.Type.displayCutout())
            view.setPadding(spacing + bars.left, spacing + bars.top, spacing + bars.right, spacing + bars.bottom)
            insets
        }
        root.addView(Button(this).apply { text = "VOLVER A BENM"; setOnClickListener { finish() } })
        val text = TextView(this).apply {
            setTextColor(0xFFE1ECF5.toInt())
            textSize = 15f
            movementMethod = LinkMovementMethod.getInstance()
            val policy = assets.open("privacy.html").bufferedReader().use { it.readText() }
            this.text = Html.fromHtml(policy, Html.FROM_HTML_MODE_LEGACY)
        }
        root.addView(ScrollView(this).apply { addView(text) }, LinearLayout.LayoutParams(-1, 0, 1f))
        setContentView(root)
    }
}
