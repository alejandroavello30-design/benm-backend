package cl.radioequipo.app

import android.Manifest
import android.content.pm.PackageManager
import android.content.Intent
import android.app.NotificationChannel
import android.app.NotificationManager
import android.os.Build
import android.os.Bundle
import android.view.MotionEvent
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import android.widget.LinearLayout
import android.widget.Toast
import android.app.AlertDialog
import android.media.AudioAttributes
import android.media.Ringtone
import android.media.RingtoneManager
import android.os.VibrationEffect
import android.os.Vibrator
import android.os.VibratorManager
import android.graphics.Typeface
import android.graphics.Color
import android.graphics.drawable.GradientDrawable
import android.view.Gravity
import android.view.View
import androidx.activity.ComponentActivity
import androidx.core.app.ActivityCompat
import androidx.core.app.NotificationCompat
import androidx.core.content.ContextCompat
import androidx.lifecycle.lifecycleScope
import io.livekit.android.events.RoomEvent
import io.livekit.android.events.collect
import io.livekit.android.room.Room
import io.livekit.android.room.track.DataPublishReliability
import kotlinx.coroutines.flow.collect
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL

class MainActivity : ComponentActivity() {

    private lateinit var room: Room
    private lateinit var tvStatus: TextView
    private lateinit var tvSpeaker: TextView
    private lateinit var tvUsers: TextView
    private lateinit var tvChannel: TextView
    private lateinit var tvEmergency: TextView
    private lateinit var btnTalk: Button
    private lateinit var btnEmergency: Button
    private lateinit var btnConnect: Button
    private lateinit var loginCard: android.view.View
    private lateinit var btnDisconnect: Button
    private lateinit var btnChangeUser: Button
    private lateinit var btnGeneral: Button
    private lateinit var btnCoordination: Button
    private lateinit var btnAttendance: Button
    private lateinit var btnFiles: Button
    private lateinit var etName: EditText
    private lateinit var etCode: EditText
    private lateinit var mainRoot: View
    private lateinit var talkArea: View
    private lateinit var tvTalkHint: TextView

    private var connectionInProgress = false
    private var connected = false
    private var userRole = "member"
    private var attendanceToken = ""
    private var serverUrl = ""
    private var currentChannel = CHANNEL_GENERAL
    private var lastEmergencyId = ""
    private var emergencyRingtone: Ringtone? = null
    private var emergencyVibrator: Vibrator? = null
    private var emergencyDialog: AlertDialog? = null
    private var pendingEmergencySender = ""
    private var pendingEmergencyType = ""
    private var pendingEmergencyMessage = ""
    private var pendingEmergencyId = ""
    private val loginPrefs by lazy { getSharedPreferences("benm_login", MODE_PRIVATE) }
    private var notificationWarningShown = false
    private var handledRadioError = 0L
    private var exitDialog: AlertDialog? = null

    companion object {
        private const val MIC_REQUEST = 501
        private const val BACKEND_URL = "https://benm-backend.onrender.com"
        private const val CHANNEL_GENERAL = "general"
        private const val CHANNEL_COORDINATION = "coordinacion"

        private const val NOTIFICATION_REQUEST = 502
        private const val EMERGENCY_NOTIFICATION_CHANNEL = "emergency_alerts_v5"
        private const val EMERGENCY_NOTIFICATION_ID = 2202
        private const val PREF_NAME = "saved_name"
        private const val PREF_CODE = "saved_code"
        private const val EXTRA_EMERGENCY_SENDER = "emergency_sender"
        private const val EXTRA_EMERGENCY_TYPE = "emergency_type"
        private const val EXTRA_EMERGENCY_MESSAGE = "emergency_message"
        private const val EXTRA_EMERGENCY_ID = "emergency_id"
    }

    private data class EmergencyType(val code: String)

    private val emergencyTypes = listOf(
        EmergencyType("ALPHA 1"),
        EmergencyType("ALPHA 2"),
        EmergencyType("SISMO"),
        EmergencyType("BETA"),
        EmergencyType("CÓDIGO G"),
        EmergencyType("INUNDACIÓN"),
        EmergencyType("EVACUACIÓN"),
        EmergencyType("EVACUACIÓN PARCIAL")
    )

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        window.decorView.systemUiVisibility = (
            View.SYSTEM_UI_FLAG_FULLSCREEN or
            View.SYSTEM_UI_FLAG_HIDE_NAVIGATION or
            View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY or
            View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN or
            View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION or
            View.SYSTEM_UI_FLAG_LAYOUT_STABLE
        )

        bindViews()
        mainRoot = findViewById(R.id.mainRoot)
        androidx.core.view.ViewCompat.setOnApplyWindowInsetsListener(mainRoot) { view, insets ->
            val safe = insets.getInsets(androidx.core.view.WindowInsetsCompat.Type.systemBars() or androidx.core.view.WindowInsetsCompat.Type.displayCutout() or androidx.core.view.WindowInsetsCompat.Type.ime())
            view.setPadding(safe.left, safe.top, safe.right, safe.bottom)
            insets
        }
        listOf(R.id.btnPrivacy, R.id.tvPrivacyFooter).forEach { id ->
            findViewById<View>(id).setOnClickListener { startActivity(Intent(this, PrivacyActivity::class.java)) }
        }
        talkArea = findViewById(R.id.talkArea)
        tvTalkHint = findViewById(R.id.tvTalkHint)
        restoreSavedLogin()
        createEmergencyNotificationChannel()
        requestNotificationPermission()
        room = RadioSession.room(applicationContext)

        btnConnect.setOnClickListener { connectToChannel(currentChannel) }
        btnDisconnect.setOnClickListener { disconnect() }
        btnChangeUser.setOnClickListener { changeUser() }
        btnGeneral.setOnClickListener { selectChannel(CHANNEL_GENERAL) }
        btnCoordination.setOnClickListener { startActivity(Intent(this, RosterActivity::class.java)) }
        btnAttendance.setOnClickListener {
            if (!connected) toast("Conecta primero con el equipo")
            else if (attendanceToken.isBlank()) toast("Actualiza el servidor para habilitar asistencia")
            else startActivity(Intent(this, AttendanceActivity::class.java).apply {
                putExtra("backendUrl", serverUrl.ifBlank { BACKEND_URL })
                putExtra("attendanceToken", attendanceToken)
                putExtra("userRole", userRole)
                putExtra("name", etName.text.toString().trim())
            })
        }
        btnFiles.setOnClickListener {
            if (!connected) {
                toast("Conecta primero con el equipo")
            } else {
                startActivity(Intent(this, FilesActivity::class.java).apply {
                    putExtra("backendUrl", serverUrl.ifBlank { BACKEND_URL })
                    putExtra("accessCode", etCode.text.toString().trim())
                    putExtra("userRole", userRole)
                })
            }
        }
        talkArea.post { adjustTalkButton() }

        btnTalk.setOnTouchListener { _, event ->
            if (!connected) return@setOnTouchListener false
            when (event.action) {
                MotionEvent.ACTION_DOWN -> {
                    if (RadioForegroundService.talk(true)) {
                        btnTalk.text = "HABLANDO..."
                        btnTalk.isPressed = true
                    } else toast("No se pudo activar el micrófono")
                    true
                }
                MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                    RadioForegroundService.talk(false)
                    btnTalk.text = "PULSAR\nPARA HABLAR"
                    btnTalk.isPressed = false
                    true
                }
                else -> true
            }
        }

        btnEmergency.setOnClickListener { showEmergencyTypeSelector() }

        lifecycleScope.launch {
            room.events.collect { event ->
                when (event) {
                    is RoomEvent.ActiveSpeakersChanged -> {
                        val names = event.speakers.joinToString(", ") {
                            it.name?.takeIf { name -> name.isNotBlank() } ?: it.identity?.value ?: "Usuario"
                        }
                        tvSpeaker.text = if (names.isBlank()) "Nadie está hablando" else "🔊 $names está hablando"
                    }
                    is RoomEvent.ParticipantConnected,
                    is RoomEvent.ParticipantDisconnected -> updateUsers()
                    // Connection state and incoming alerts belong to the service.
                    else -> Unit
                }
            }
        }
        applyRadioState(RadioSession.state.value)
        lifecycleScope.launch { RadioSession.state.collect { applyRadioState(it) } }
        lifecycleScope.launch {
            RadioSession.pendingAlert.collect { alert ->
                if (alert != null) handleEmergencyData(alert.payload(), alert.sender)
                else {
                    pendingEmergencyType = ""
                    emergencyDialog?.dismiss()
                    stopEmergencyAlertSignal(cancelNotification = false)
                }
            }
        }
    }

    override fun onNewIntent(intent: Intent?) {
        super.onNewIntent(intent)
        setIntent(intent)
        if (intent != null) {
            readEmergencyIntent(intent)
            readSessionAction(intent)
            if (lifecycle.currentState.isAtLeast(androidx.lifecycle.Lifecycle.State.RESUMED)) {
                showPendingEmergencyIfNeeded()
            }
        }
    }

    override fun onResume() {
        super.onResume()
        RadioSession.uiVisible = true
        runCatching { RadioForegroundService.resumeIfEnabled(this) }
        applyRadioState(RadioSession.state.value)
        readEmergencyIntent(intent)
        readSessionAction(intent)
        showPendingEmergencyIfNeeded()
    }

    override fun onPause() {
        RadioSession.uiVisible = false
        RadioForegroundService.talk(false)
        btnTalk.isPressed = false
        btnTalk.text = "PULSAR\nPARA HABLAR"
        stopEmergencyAlertSignal(cancelNotification = false)
        super.onPause()
    }

    private fun readEmergencyIntent(intent: Intent?) {
        if (intent == null) return
        val type = intent.getStringExtra(EXTRA_EMERGENCY_TYPE).orEmpty()
        if (type.isBlank()) return
        pendingEmergencySender = intent.getStringExtra(EXTRA_EMERGENCY_SENDER).orEmpty().ifBlank { "Usuario" }
        pendingEmergencyType = type
        pendingEmergencyMessage = intent.getStringExtra(EXTRA_EMERGENCY_MESSAGE).orEmpty().ifBlank { type }
        pendingEmergencyId = intent.getStringExtra(EXTRA_EMERGENCY_ID).orEmpty()
        lastEmergencyId = pendingEmergencyId
        intent.removeExtra(EXTRA_EMERGENCY_TYPE)
        intent.removeExtra(EXTRA_EMERGENCY_SENDER)
        intent.removeExtra(EXTRA_EMERGENCY_MESSAGE)
        intent.removeExtra(EXTRA_EMERGENCY_ID)
    }

    private fun showPendingEmergencyIfNeeded() {
        if (pendingEmergencyType.isBlank()) return
        if (emergencyDialog?.isShowing == true) return
        val sender = pendingEmergencySender
        val type = pendingEmergencyType
        val message = pendingEmergencyMessage
        pendingEmergencySender = ""
        pendingEmergencyType = ""
        pendingEmergencyMessage = ""
        showInAppEmergencyDialog(sender, type, message)
    }

    private fun bindViews() {
        tvStatus = findViewById(R.id.tvStatus)
        tvSpeaker = findViewById(R.id.tvSpeaker)
        tvUsers = findViewById(R.id.tvUsers)
        tvChannel = findViewById(R.id.tvChannel)
        tvEmergency = findViewById(R.id.tvEmergency)
        btnTalk = findViewById(R.id.btnTalk)
        btnEmergency = findViewById(R.id.btnEmergency)
        btnConnect = findViewById(R.id.btnConnect)
        loginCard = findViewById(R.id.loginCard)
        btnDisconnect = findViewById(R.id.btnDisconnect)
        btnChangeUser = findViewById(R.id.btnChangeUser)
        btnGeneral = findViewById(R.id.btnGeneral)
        btnCoordination = findViewById(R.id.btnCoordination)
        btnAttendance = findViewById(R.id.btnAttendance)
        btnFiles = findViewById(R.id.btnFiles)
        etName = findViewById(R.id.etName)
        etCode = findViewById(R.id.etAccessCode)
    }

    private fun selectChannel(channel: String) {
        if (connected && channel == currentChannel) return
        currentChannel = channel
        tvChannel.text = "CANAL: ${displayChannel(channel)}"
        updateChannelButtons()
        if (connected) connectToChannel(channel) else toast("Canal seleccionado: ${displayChannel(channel)}")
    }

    private fun updateChannelButtons() {
        btnGeneral.alpha = if (currentChannel == CHANNEL_GENERAL) 1f else 0.55f
        btnCoordination.alpha = 1f
    }

    private fun displayChannel(channel: String): String = when (channel) {
        CHANNEL_COORDINATION -> "COORDINACIÓN"
        else -> "GENERAL"
    }

    private fun connectToChannel(channel: String, recoverSession: Boolean = false) {
        if (connectionInProgress) return
        val name = etName.text.toString().trim()
        val code = etCode.text.toString().trim()
        if (name.isBlank()) { etName.error = "Escribe tu nombre"; return }
        if (code.isBlank()) { etCode.error = "Escribe el código"; return }
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(this, arrayOf(Manifest.permission.RECORD_AUDIO), MIC_REQUEST)
            return
        }
        connectionInProgress = true
        updateConnectionControls()
        tvStatus.text = "● Conectando…"
        try { RadioForegroundService.connect(this, name, code, channel, recoverSession) }
        catch (error: Exception) {
            connectionInProgress = false
            updateConnectionControls()
            toast("No se pudo iniciar la radio. Abre BENM e intenta nuevamente.")
        }
    }

    private fun applyRadioState(state: RadioState) {
        connectionInProgress = state.phase == RadioPhase.CONNECTING || state.phase == RadioPhase.RECONNECTING
        connected = state.phase == RadioPhase.CONNECTED || state.phase == RadioPhase.RECONNECTING
        currentChannel = state.channel
        serverUrl = state.backend
        userRole = state.role
        attendanceToken = state.attendanceToken
        if (state.phase == RadioPhase.CONNECTED) {
            etName.setText(state.name)
            etCode.setText(loginPrefs.getString(PREF_CODE, "").orEmpty())
        }
        setUiConnected(connected)
        updateChannelButtons()
        tvChannel.text = "CANAL: ${displayChannel(currentChannel)}"
        tvStatus.text = when (state.phase) {
            RadioPhase.CONNECTING -> "● CONECTANDO…"
            RadioPhase.RECONNECTING -> "● RECONECTANDO…"
            RadioPhase.CONNECTED -> "● CONECTADO"
            RadioPhase.ERROR, RadioPhase.NAME_IN_USE -> "● DESCONECTADO"
            else -> "● DESCONECTADO"
        }
        updateUsers()
        if (state.phase == RadioPhase.CONNECTED && RadioSession.uiVisible && !notificationWarningShown) {
            val manager = getSystemService(NotificationManager::class.java)
            if (!manager.areNotificationsEnabled() || manager.getNotificationChannel(EMERGENCY_NOTIFICATION_CHANNEL)?.importance == NotificationManager.IMPORTANCE_NONE) {
                notificationWarningShown = true
                toast("Activa las notificaciones de BENM para ver los avisos fuera de la app")
            }
        }
        if (state.phase in listOf(RadioPhase.ERROR, RadioPhase.NAME_IN_USE) && RadioSession.uiVisible && state.attempt != handledRadioError) {
            handledRadioError = state.attempt
            if (state.phase == RadioPhase.NAME_IN_USE && !state.recovering) showSessionRecovery(state.channel)
            else toast(state.error.ifBlank { "No se pudo conectar" })
        }
    }

    private fun showSessionRecovery(channel: String) {
        AlertDialog.Builder(this)
            .setTitle("Nombre conectado")
            .setMessage("Tu nombre sigue conectado. Si esa conexión es tuya, puedes recuperar la sesión. Esto cerrará la conexión anterior con el mismo nombre en este canal.")
            .setNegativeButton("CANCELAR", null)
            .setPositiveButton("RECUPERAR SESIÓN") { _, _ -> connectToChannel(channel, recoverSession = true) }
            .show()
    }

    private fun updateConnectionControls() {
        btnConnect.isEnabled = !connected && !connectionInProgress
        btnDisconnect.isEnabled = connected || connectionInProgress
        btnChangeUser.isEnabled = true
        btnGeneral.isEnabled = !connectionInProgress
        btnCoordination.isEnabled = true
        btnAttendance.isEnabled = connected && !connectionInProgress
        btnFiles.isEnabled = connected && !connectionInProgress
        btnTalk.isEnabled = connected && !connectionInProgress
        btnEmergency.isEnabled = connected && !connectionInProgress
    }

    private fun disconnect() { confirmSessionExit(logout = false) }

    private fun readSessionAction(intent: Intent?) {
        if (RadioSession.uiVisible && intent?.getBooleanExtra("confirm_disconnect", false) == true) {
            intent.removeExtra("confirm_disconnect")
            confirmSessionExit(logout = false)
        }
    }

    private fun confirmSessionExit(logout: Boolean) {
        if (exitDialog?.isShowing == true) return
        exitDialog = AlertDialog.Builder(this)
            .setTitle(if (logout) "¿Salir y cambiar de usuario?" else "¿Desconectar BENM?")
            .setMessage(if (logout) "Dejarás de recibir radio y avisos. También se borrarán el nombre y el código guardados."
                else "Dejarás de recibir radio y avisos hasta volver a conectar. Tu nombre y código quedarán guardados.")
            .setNegativeButton("CANCELAR", null)
            .setPositiveButton(if (logout) "SALIR" else "DESCONECTAR") { _, _ -> completeSessionExit(logout) }
            .create().also { dialog -> dialog.setOnDismissListener { exitDialog = null }; dialog.show() }
    }

    private fun completeSessionExit(logout: Boolean) {
        RadioForegroundService.stop(this)
        stopEmergencyAlertSignal()
        emergencyDialog?.dismiss()
        applyRadioState(RadioSession.state.value)
        if (logout) {
            loginPrefs.edit().clear().apply()
            etName.setText("")
            etCode.setText("")
            tvStatus.text = "● DESCONECTADO — ingresa otro usuario"
            toast("Sesión cerrada. Puedes ingresar otro usuario.")
        }
    }

    private fun setUiConnected(value: Boolean) {
        btnConnect.isEnabled = !value
        btnDisconnect.isEnabled = value
        btnChangeUser.isEnabled = true
        loginCard.visibility = if (value) View.GONE else View.VISIBLE
        btnTalk.isEnabled = value
        btnEmergency.isEnabled = value
        btnFiles.isEnabled = value
        btnGeneral.isEnabled = true
        btnCoordination.isEnabled = true
        btnAttendance.isEnabled = true
        etName.visibility = if (value) View.GONE else View.VISIBLE
        etCode.visibility = if (value) View.GONE else View.VISIBLE
        btnConnect.visibility = if (value) View.GONE else View.VISIBLE
        btnDisconnect.visibility = if (value) View.VISIBLE else View.GONE
        btnChangeUser.visibility = if (value) View.VISIBLE else View.GONE
        tvStatus.text = if (value) "● CONECTADO" else "● DESCONECTADO"
        updateConnectionControls()
    }


    private fun restoreSavedLogin() {
        val savedName = loginPrefs.getString(PREF_NAME, "").orEmpty()
        val savedCode = loginPrefs.getString(PREF_CODE, "").orEmpty()
        if (savedName.isNotBlank()) etName.setText(savedName)
        if (savedCode.isNotBlank()) etCode.setText(savedCode)
    }

    private fun changeUser() { confirmSessionExit(logout = true) }

    private fun updateUsers() {
        if (!connected) { tvUsers.text = "Integrantes conectados: 0"; return }
        val participants = room.remoteParticipants.values.toList()
        val count = participants.size + 1
        val names = buildList {
            add("Tú: ${etName.text.toString().trim()}")
            participants.forEach { participant ->
                add(participant.name?.takeIf { it.isNotBlank() } ?: participant.identity?.value ?: "Usuario")
            }
        }
        tvUsers.text = "Integrantes conectados: $count\n" + names.joinToString("\n") { "• $it" }
    }

    private fun showEmergencyTypeSelector() {
        if (!connected) {
            toast("Conecta primero con el equipo")
            return
        }

        val content = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(16), dp(4), dp(16), dp(8))
        }
        val scroll = android.widget.ScrollView(this).apply {
            isFillViewport = true
            addView(content, android.widget.FrameLayout.LayoutParams(-1, -2))
        }

        val dialog = AlertDialog.Builder(this)
            .setTitle("🚨  SELECCIONA LA ALERTA")
            .setView(scroll)
            .setNegativeButton("CANCELAR", null)
            .create()

        emergencyTypes.chunked(2).forEach { rowTypes ->
            val row = LinearLayout(this).apply {
                orientation = LinearLayout.HORIZONTAL
                gravity = Gravity.CENTER
            }
            rowTypes.forEach { type ->
                val button = Button(this).apply {
                    text = when (type.code) {
                        "ALPHA 1" -> "🔥  ALPHA 1"
                        "ALPHA 2" -> "🛑  ALPHA 2"
                        "SISMO" -> "〰  SISMO"
                        "BETA" -> "⚠  BETA"
                        "CÓDIGO G" -> "🟡  CÓDIGO G"
                        "INUNDACIÓN" -> "🌊  INUNDACIÓN"
                        "EVACUACIÓN" -> "🏃  EVACUACIÓN"
                        else -> "📍  EVACUACIÓN PARCIAL"
                    }
                    textSize = if (type.code == "EVACUACIÓN PARCIAL") 13f else 15f
                    isAllCaps = false
                    minHeight = dp(62)
                    setTextColor(Color.WHITE)
                    setTypeface(typeface, Typeface.BOLD)
                    setPadding(dp(6), 0, dp(6), 0)
                    background = roundedEmergencyButton(emergencyColor(type.code))
                    elevation = dp(2).toFloat()
                    setOnClickListener {
                        dialog.dismiss()
                        if (type.code == "EVACUACIÓN PARCIAL") {
                            showPartialEvacuationLocation()
                        } else {
                            sendEmergencyAlert(type, null)
                        }
                    }
                }
                val lp = LinearLayout.LayoutParams(0, dp(68), 1f).apply {
                    setMargins(dp(4), dp(5), dp(4), dp(5))
                }
                row.addView(button, lp)
            }
            if (rowTypes.size == 1) {
                row.addView(View(this), LinearLayout.LayoutParams(0, dp(68), 1f).apply {
                    setMargins(dp(4), dp(5), dp(4), dp(5))
                })
            }
            content.addView(row)
        }

        dialog.show()
    }

    private fun emergencyColor(code: String): Int = when (code) {
        "ALPHA 1" -> Color.rgb(225, 48, 38)
        "ALPHA 2" -> Color.rgb(150, 35, 45)
        "SISMO" -> Color.rgb(245, 142, 20)
        "BETA" -> Color.rgb(210, 105, 20)
        "CÓDIGO G" -> Color.rgb(195, 155, 20)
        "INUNDACIÓN" -> Color.rgb(25, 125, 205)
        "EVACUACIÓN" -> Color.rgb(25, 155, 85)
        else -> Color.rgb(115, 85, 190)
    }

    private fun roundedEmergencyButton(color: Int): GradientDrawable =
        GradientDrawable().apply {
            setColor(color)
            cornerRadius = dp(16).toFloat()
            setStroke(dp(1), Color.argb(150, 255, 255, 255))
        }

    private fun showPartialEvacuationLocation() {
        val input = EditText(this).apply {
            hint = "Ej.: Segundo piso, sector oficinas"
            setSingleLine(false)
            minLines = 2
            maxLines = 3
            setPadding(24, 16, 24, 16)
        }

        val container = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(28, 0, 28, 0)
            addView(input, LinearLayout.LayoutParams(-1, LinearLayout.LayoutParams.WRAP_CONTENT))
        }

        val dialog = AlertDialog.Builder(this)
            .setTitle("🟠 EVACUACIÓN PARCIAL")
            .setMessage("Indica dónde se realizará la evacuación.")
            .setView(container)
            .setNegativeButton("CANCELAR", null)
            .setPositiveButton("ENVIAR ALERTA", null)
            .create()

        dialog.setOnShowListener {
            dialog.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener {
                val location = input.text.toString().trim()
                if (location.isBlank()) {
                    input.error = "Indica el lugar de la evacuación"
                    return@setOnClickListener
                }
                dialog.dismiss()
                sendEmergencyAlert(EmergencyType("EVACUACIÓN PARCIAL"), location)
            }
        }
        dialog.show()
    }

    private fun sendEmergencyAlert(type: EmergencyType, location: String?) {
        val name = etName.text.toString().trim().ifBlank { "Usuario" }
        val message = if (type.code == "EVACUACIÓN PARCIAL" && !location.isNullOrBlank()) {
            "Lugar: $location"
        } else {
            type.code
        }

        lifecycleScope.launch {
            btnEmergency.isEnabled = false
            try {
                val alert = withContext(Dispatchers.IO) {
                    postEmergency(serverUrl, name, currentChannel, if (type.code == "EVACUACIÓN PARCIAL") "${type.code} | $message" else type.code)
                }
                lastEmergencyId = alert.id
                val payload = JSONObject()
                    .put("type", "emergency")
                    .put("id", alert.id)
                    .put("sender", name)
                    .put("emergencyType", type.code)
                    .put("message", message)
                    .toString()
                    .toByteArray(Charsets.UTF_8)
                room.localParticipant.publishData(
                    payload,
                    DataPublishReliability.RELIABLE,
                    "emergency"
                )
                tvEmergency.text = if (type.code == "EVACUACIÓN PARCIAL") {
                    "🚨 ${type.code} ENVIADA · $location"
                } else {
                    "🚨 ${type.code} ENVIADA"
                }
            } catch (e: Exception) {
                toast(e.message ?: "No se pudo enviar la alerta")
            } finally {
                btnEmergency.isEnabled = connected
            }
        }
    }

    private fun adjustTalkButton() {
        if (!::talkArea.isInitialized || !::btnTalk.isInitialized) return
        if (talkArea.width <= 0 || talkArea.height <= 0) return

        // El centro de la pantalla es flexible: el botón crece con el espacio
        // disponible y los controles inferiores quedan siempre al final.
        val horizontalLimit = (talkArea.width * 0.92f).toInt()
        val hintHeight = if (::tvTalkHint.isInitialized) tvTalkHint.height else 0
        val verticalLimit = talkArea.height - hintHeight - dp(24)
        val size = minOf(horizontalLimit, verticalLimit, dp(300)).coerceAtLeast(dp(105))

        val lp = btnTalk.layoutParams
        lp.width = size
        lp.height = size
        btnTalk.layoutParams = lp
    }

    private fun dp(value: Int): Int =
        (value * resources.displayMetrics.density).toInt()

    override fun onWindowFocusChanged(hasFocus: Boolean) {
        super.onWindowFocusChanged(hasFocus)
        if (hasFocus && ::talkArea.isInitialized) {
            talkArea.post { adjustTalkButton() }
        }
    }

    private fun handleEmergencyData(data: ByteArray, fallbackSender: String) {
        val json = runCatching { JSONObject(String(data, Charsets.UTF_8)) }.getOrNull() ?: return
        if (json.optString("type") != "emergency") return
        val id = json.optString("id").ifBlank { return }
        if (id == lastEmergencyId) return
        lastEmergencyId = id
        val sender = json.optString("sender").ifBlank { fallbackSender }
        val emergencyType = json.optString("emergencyType").ifBlank { "EMERGENCIA" }
        val emergencyMessage = json.optString("message").ifBlank { emergencyType }

        pendingEmergencySender = sender
        pendingEmergencyType = emergencyType
        pendingEmergencyMessage = emergencyMessage
        pendingEmergencyId = id

        // La alerta recibida no intenta arrancar una Activity desde segundo plano.
        // Esto evita el cierre forzoso que ocurría al lanzar la pantalla roja
        // desde el callback de LiveKit. La notificación sigue siendo de alta
        // prioridad y al tocarla se puede abrir la pantalla de alerta.
        // The service already posted the notification and deduplicated the alert.

        if (lifecycle.currentState.isAtLeast(androidx.lifecycle.Lifecycle.State.RESUMED)) {
            showPendingEmergencyIfNeeded()
        }
    }

    private fun showInAppEmergencyDialog(sender: String, emergencyType: String, emergencyMessage: String) {
        runCatching {
            emergencyDialog?.dismiss()
            startEmergencyAlertSignal()

            val container = android.widget.LinearLayout(this).apply {
                orientation = android.widget.LinearLayout.VERTICAL
                gravity = Gravity.CENTER
                setPadding(32, 28, 32, 28)
                setBackgroundResource(R.drawable.bg_alert)
            }

            val icon = TextView(this).apply {
                text = "🚨"
                textSize = 56f
                gravity = Gravity.CENTER
            }
            container.addView(icon, android.widget.LinearLayout.LayoutParams(-1, -2))

            val title = TextView(this).apply {
                text = emergencyType
                textSize = 34f
                typeface = Typeface.DEFAULT_BOLD
                setTextColor(0xFFFFFFFF.toInt())
                gravity = Gravity.CENTER
                setPadding(0, 8, 0, 8)
            }
            container.addView(title, android.widget.LinearLayout.LayoutParams(-1, -2))

            val alertText = TextView(this).apply {
                text = if (emergencyType == "EVACUACIÓN PARCIAL") emergencyMessage else "ALERTA ACTIVADA"
                textSize = 18f
                typeface = Typeface.DEFAULT_BOLD
                setTextColor(0xFFFFD9DC.toInt())
                gravity = Gravity.CENTER
            }
            container.addView(alertText, android.widget.LinearLayout.LayoutParams(-1, -2))

            val who = TextView(this).apply {
                text = "Por: $sender"
                textSize = 20f
                setTextColor(0xFFFFFFFF.toInt())
                gravity = Gravity.CENTER
                setPadding(0, 18, 0, 22)
            }
            container.addView(who, android.widget.LinearLayout.LayoutParams(-1, -2))

            val acknowledge = Button(this).apply {
                text = "RECONOCER ALERTA"
                textSize = 18f
                typeface = Typeface.DEFAULT_BOLD
                setTextColor(0xFFFFFFFF.toInt())
                background = ContextCompat.getDrawable(context, R.drawable.bg_alert_button)
                setOnClickListener {
                    RadioSession.acknowledge(pendingEmergencyId)
                    stopEmergencyAlertSignal()
                    emergencyDialog?.dismiss()
                }
            }
            container.addView(acknowledge, android.widget.LinearLayout.LayoutParams(-1, 70))

            emergencyDialog = AlertDialog.Builder(this)
                .setView(container)
                .setCancelable(false)
                .create()
            emergencyDialog?.window?.setBackgroundDrawableResource(android.R.color.transparent)
            emergencyDialog?.setOnDismissListener { stopEmergencyAlertSignal(cancelNotification = false) }
            emergencyDialog?.show()
            emergencyDialog?.window?.setLayout(
                (resources.displayMetrics.widthPixels * 0.90).toInt(),
                android.view.WindowManager.LayoutParams.WRAP_CONTENT
            )
        }
    }

    private fun startEmergencyAlertSignal() {
        runCatching {
            val uri = RingtoneManager.getDefaultUri(RingtoneManager.TYPE_ALARM)
                ?: RingtoneManager.getDefaultUri(RingtoneManager.TYPE_NOTIFICATION)
            emergencyRingtone?.stop()
            emergencyRingtone = RingtoneManager.getRingtone(this, uri)
            emergencyRingtone?.audioAttributes = AudioAttributes.Builder()
                .setUsage(AudioAttributes.USAGE_ALARM)
                .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION)
                .build()
            emergencyRingtone?.play()

            emergencyVibrator = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
                getSystemService(VibratorManager::class.java).defaultVibrator
            } else {
                @Suppress("DEPRECATION")
                getSystemService(VIBRATOR_SERVICE) as Vibrator
            }
            val pattern = longArrayOf(0, 500, 250, 500, 250, 900)
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                emergencyVibrator?.vibrate(VibrationEffect.createWaveform(pattern, 0))
            } else {
                @Suppress("DEPRECATION")
                emergencyVibrator?.vibrate(pattern, 0)
            }
        }
    }

    private fun stopEmergencyAlertSignal(cancelNotification: Boolean = true) {
        runCatching { emergencyRingtone?.stop() }
        runCatching { emergencyVibrator?.cancel() }
        if (cancelNotification) runCatching { getSystemService(NotificationManager::class.java).cancel(EMERGENCY_NOTIFICATION_ID) }
        emergencyRingtone = null
        emergencyVibrator = null
    }

    private fun postEmergency(base: String, sender: String, channel: String, emergencyType: String): EmergencyAlert {
        val url = URL("$base/emergency")
        val connection = (url.openConnection() as HttpURLConnection).apply {
            requestMethod = "POST"; doOutput = true; connectTimeout = 10_000; readTimeout = 10_000
            setRequestProperty("Content-Type", "application/json")
        }
        try {
            val body = JSONObject().put("sender", sender).put("room", channel).put("message", emergencyType).toString()
            connection.outputStream.use { it.write(body.toByteArray(Charsets.UTF_8)) }
            val status = connection.responseCode
            if (status !in 200..299) {
                val stream = connection.errorStream
                val response = stream?.bufferedReader()?.use { it.readText() }.orEmpty()
                val message = runCatching { JSONObject(response).optString("error") }.getOrDefault("")
                throw IllegalStateException(message.ifBlank { "Servidor de alertas no disponible ($status)" })
            }
            val json = JSONObject(connection.inputStream.bufferedReader().use { it.readText() })
            val alert = json.getJSONObject("alert")
            return EmergencyAlert(
                alert.getString("id"),
                alert.getString("sender"),
                alert.getString("message")
            )
        } finally { connection.disconnect() }
    }

    private fun createEmergencyNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val manager = getSystemService(NotificationManager::class.java)
            val channel = NotificationChannel(
                EMERGENCY_NOTIFICATION_CHANNEL,
                "Emergencias BENM",
                NotificationManager.IMPORTANCE_HIGH
            ).apply {
                description = "Alertas urgentes del equipo BENM"
                enableVibration(true)
                vibrationPattern = longArrayOf(0, 500, 250, 500, 250, 900)
                setSound(
                    android.media.RingtoneManager.getDefaultUri(android.media.RingtoneManager.TYPE_ALARM),
                    android.media.AudioAttributes.Builder()
                        .setUsage(android.media.AudioAttributes.USAGE_ALARM)
                        .setContentType(android.media.AudioAttributes.CONTENT_TYPE_SONIFICATION)
                        .build()
                )
                lockscreenVisibility = NotificationCompat.VISIBILITY_PUBLIC
            }
            manager.createNotificationChannel(channel)
        }
    }

    private fun requestNotificationPermission() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU &&
            ContextCompat.checkSelfPermission(this, Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
        ) {
            ActivityCompat.requestPermissions(this, arrayOf(Manifest.permission.POST_NOTIFICATIONS), NOTIFICATION_REQUEST)
        }
    }

    private fun toast(message: String) = Toast.makeText(this, message, Toast.LENGTH_SHORT).show()

    override fun onDestroy() {
        exitDialog?.dismiss()
        RadioForegroundService.talk(false)
        stopEmergencyAlertSignal(cancelNotification = false)
        emergencyDialog?.dismiss()
        super.onDestroy()
    }

    data class EmergencyAlert(val id: String, val sender: String, val message: String)
}
