package cl.radioequipo.app

/** Shared duplicate guard, restored by the service after process recreation. */
class AlertLedger(previous: List<String> = emptyList()) {
    private val ids = LinkedHashSet(previous.takeLast(128))
    fun accept(id: String, sender: String, self: String): Boolean {
        if (id.isBlank() || !ids.add(id)) return false
        while (ids.size > 128) ids.remove(ids.first())
        return !sender.trim().equals(self.trim(), ignoreCase = true)
    }
    fun seed(id: String) { if (id.isNotBlank()) accept(id, "", "") }
    fun snapshot() = ids.toList()
}
