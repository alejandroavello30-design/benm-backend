package cl.radioequipo.app

import android.app.DatePickerDialog
import android.graphics.Color
import android.os.Bundle
import android.widget.*
import androidx.activity.ComponentActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import androidx.lifecycle.lifecycleScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.time.LocalDate
import java.time.ZoneId
import java.time.Instant
import java.time.format.DateTimeFormatter
import androidx.activity.result.contract.ActivityResultContracts
import android.content.Intent
import org.json.JSONArray

class AttendanceActivity : ComponentActivity() {
    private val base by lazy { intent.getStringExtra("backendUrl").orEmpty().trimEnd('/') }
    private val token by lazy { intent.getStringExtra("attendanceToken").orEmpty() }
    private val name by lazy { intent.getStringExtra("name").orEmpty() }
    private val admin by lazy { intent.getStringExtra("userRole") == "admin" }
    private var selectedDate = LocalDate.now(ZoneId.of("America/Santiago")).toString()
    private lateinit var dateButton: Button
    private lateinit var markButton: Button
    private lateinit var refreshButton: Button
    private lateinit var exportButton: Button
    private lateinit var otherName: EditText
    private lateinit var summary: TextView
    private lateinit var list: LinearLayout
    private var busy = false
    private var serverToday = selectedDate
    private var records = JSONArray()
    private var pendingExport: String? = null
    private val saveCsv = registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { result ->
        val csv = pendingExport
        pendingExport = null
        val uri = result.data?.data
        if (result.resultCode == RESULT_OK && uri != null && csv != null) {
            lifecycleScope.launch {
                try {
                    withContext(Dispatchers.IO) {
                        val output = contentResolver.openOutputStream(uri) ?: error("No se pudo abrir el archivo")
                        output.use { it.write(csv.toByteArray(Charsets.UTF_8)) }
                    }
                    Toast.makeText(this@AttendanceActivity, "Archivo de asistencia guardado", Toast.LENGTH_LONG).show()
                } catch (error: Exception) {
                    Toast.makeText(this@AttendanceActivity, "No se pudo guardar: ${error.message}", Toast.LENGTH_LONG).show()
                }
            }
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        selectedDate = savedInstanceState?.getString("date") ?: selectedDate
        pendingExport = savedInstanceState?.getString("export")
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(16, 16, 16, 12)
            setBackgroundColor(Color.rgb(10, 18, 28))
        }
        ViewCompat.setOnApplyWindowInsetsListener(root) { view, insets ->
            val bars = insets.getInsets(WindowInsetsCompat.Type.systemBars() or WindowInsetsCompat.Type.ime())
            view.setPadding(16 + bars.left, 16 + bars.top, 16 + bars.right, 12 + bars.bottom)
            insets
        }
        fun label(value: String, size: Float = 14f) = TextView(this).apply {
            text = value; textSize = size; setTextColor(Color.WHITE); setPadding(4, 8, 4, 8)
        }
        root.addView(label("ASISTENCIA DIARIA", 24f))
        root.addView(label(if (admin) "ADMINISTRADOR · $name\nRegistra tu asistencia o la de otro miembro." else "$name\nPuedes ver la asistencia del equipo. Marca tu propia asistencia de hoy."))
        root.addView(label("Fechas y horas de Chile · Un registro por nombre y día", 12f))
        dateButton = Button(this).apply {
            text = selectedDate
            setOnClickListener {
                val date = LocalDate.parse(selectedDate)
                DatePickerDialog(this@AttendanceActivity, { _, year, month, day ->
                    selectedDate = LocalDate.of(year, month + 1, day).toString()
                    dateButton.text = selectedDate
                    load()
                }, date.year, date.monthValue - 1, date.dayOfMonth).apply {
                    datePicker.maxDate = System.currentTimeMillis()
                }.show()
            }
        }
        root.addView(dateButton)
        otherName = EditText(this).apply {
            hint = "Nombre del miembro (vacío: mi asistencia)"
            setTextColor(Color.WHITE); setHintTextColor(Color.LTGRAY)
            inputType = android.text.InputType.TYPE_CLASS_TEXT or android.text.InputType.TYPE_TEXT_FLAG_CAP_WORDS
            filters = arrayOf(android.text.InputFilter.LengthFilter(30))
            visibility = if (admin) android.view.View.VISIBLE else android.view.View.GONE
        }
        root.addView(otherName)
        markButton = Button(this).apply {
            text = if (admin) "REGISTRAR ASISTENCIA" else "MARCAR MI ASISTENCIA"
            setOnClickListener { mark() }
        }
        root.addView(markButton)
        refreshButton = Button(this).apply { text = "ACTUALIZAR LISTADO"; setOnClickListener { load() } }
        root.addView(refreshButton)
        exportButton = Button(this).apply {
            text = "EXPORTAR FECHA A CSV (EXCEL)"
            visibility = if (admin) android.view.View.VISIBLE else android.view.View.GONE
            isEnabled = false
            setOnClickListener {
                pendingExport = AttendanceCsv.encode(selectedDate, records)
                saveCsv.launch(Intent(Intent.ACTION_CREATE_DOCUMENT).apply {
                    addCategory(Intent.CATEGORY_OPENABLE)
                    type = "text/csv"
                    putExtra(Intent.EXTRA_TITLE, "BENM-asistencia-$selectedDate.csv")
                })
            }
        }
        root.addView(exportButton)
        summary = label("Cargando…")
        root.addView(summary)
        list = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        root.addView(ScrollView(this).apply { addView(list) }, LinearLayout.LayoutParams(-1, 0, 1f))
        root.addView(Button(this).apply { text = "VOLVER A RADIO"; setOnClickListener { finish() } })
        setContentView(root)
        load(initial = savedInstanceState == null)
    }

    override fun onSaveInstanceState(outState: Bundle) {
        outState.putString("date", selectedDate)
        outState.putString("export", pendingExport)
        super.onSaveInstanceState(outState)
    }

    private fun setBusy(value: Boolean) {
        busy = value
        dateButton.isEnabled = !value
        markButton.isEnabled = !value && (admin || selectedDate == serverToday)
        refreshButton.isEnabled = !value
        otherName.isEnabled = !value
        exportButton.isEnabled = !value && records.length() > 0
    }

    private suspend fun request(method: String, body: JSONObject? = null, initial: Boolean = false): JSONObject = withContext(Dispatchers.IO) {
        val connection = URL("$base/attendance" + if (method == "GET" && !initial) "?date=$selectedDate" else "").openConnection() as HttpURLConnection
        try {
            connection.requestMethod = method
            connection.connectTimeout = 15000
            connection.readTimeout = 20000
            connection.setRequestProperty("Authorization", "Bearer $token")
            connection.setRequestProperty("Accept", "application/json")
            if (body != null) {
                connection.doOutput = true
                connection.setRequestProperty("Content-Type", "application/json; charset=utf-8")
                connection.outputStream.use { it.write(body.toString().toByteArray(Charsets.UTF_8)) }
            }
            val status = connection.responseCode
            val stream = if (status in 200..299) connection.inputStream else connection.errorStream
            val text = stream?.bufferedReader()?.use { it.readText() }.orEmpty()
            val json = runCatching { JSONObject(text) }.getOrElse { JSONObject() }
            if (status !in 200..299) throw IllegalStateException(json.optString("error").ifBlank { "No se pudo acceder a asistencia ($status)." })
            json
        } finally { connection.disconnect() }
    }

    private fun load(initial: Boolean = false) {
        if (busy) return
        setBusy(true)
        lifecycleScope.launch {
            try { render(request("GET", initial = initial)) }
            catch (error: Exception) { summary.text = error.message ?: "No se pudo consultar la asistencia"; list.removeAllViews(); records = JSONArray() }
            finally { setBusy(false) }
        }
    }

    private fun mark() {
        if (busy) return
        val target = if (admin) otherName.text.toString().trim().ifBlank { name } else name
        android.app.AlertDialog.Builder(this)
            .setTitle("Confirmar asistencia")
            .setMessage("$target\nFecha: $selectedDate")
            .setNegativeButton("CANCELAR", null)
            .setPositiveButton("REGISTRAR") { _, _ ->
                setBusy(true)
                lifecycleScope.launch {
                    try {
                        val result = request("POST", JSONObject().put("name", target).put("date", selectedDate))
                        Toast.makeText(this@AttendanceActivity, if (result.optBoolean("duplicate")) "La asistencia ya estaba registrada" else "Asistencia guardada", Toast.LENGTH_LONG).show()
                        render(request("GET"))
                    } catch (error: Exception) {
                        summary.text = error.message ?: "No se pudo confirmar el registro. Actualiza el listado antes de reintentar."
                    } finally { setBusy(false) }
                }
            }.show()
    }

    private fun render(json: JSONObject) {
        selectedDate = json.getString("date")
        serverToday = json.getString("today")
        dateButton.text = selectedDate
        val rows = json.getJSONArray("records")
        records = rows
        summary.text = if (rows.length() == 0) "Sin asistencia registrada para esta fecha" else "Asistencias registradas: ${rows.length()}"
        list.removeAllViews()
        for (index in 0 until rows.length()) {
            val row = rows.getJSONObject(index)
            val time = runCatching {
                Instant.parse(row.getString("markedAt")).atZone(ZoneId.of("America/Santiago")).format(DateTimeFormatter.ofPattern("dd/MM/yyyy HH:mm"))
            }.getOrDefault(row.optString("markedAt"))
            list.addView(TextView(this).apply {
                text = "✓ ${row.getString("name")}\nRegistrada: $time\nPor: ${row.getString("markedBy")}"; textSize = 16f
                setTextColor(Color.WHITE); setPadding(8, 14, 8, 14)
            })
        }
    }
}
