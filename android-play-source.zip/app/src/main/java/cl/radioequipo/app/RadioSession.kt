package cl.radioequipo.app

import android.content.Context
import android.media.AudioManager
import com.twilio.audioswitch.AudioDevice
import io.livekit.android.AudioOptions
import io.livekit.android.LiveKit
import io.livekit.android.LiveKitOverrides
import io.livekit.android.audio.AudioSwitchHandler
import io.livekit.android.room.Room
import kotlinx.coroutines.flow.MutableStateFlow

enum class RadioPhase { IDLE, CONNECTING, CONNECTED, RECONNECTING, ERROR, NAME_IN_USE }
data class RadioState(
    val phase: RadioPhase = RadioPhase.IDLE, val name: String = "", val channel: String = "general",
    val backend: String = "https://benm-backend.onrender.com", val role: String = "member",
    val attendanceToken: String = "", val error: String = "", val attempt: Long = 0,
    val recovering: Boolean = false
)

object RadioSession {
    val state = MutableStateFlow(RadioState())
    val pendingAlert = MutableStateFlow<EmergencyMessage?>(null)
    var uiVisible = false
    @android.annotation.SuppressLint("StaticFieldLeak") // LiveKit is initialized with applicationContext only.
    private var sharedRoom: Room? = null
    @Synchronized fun room(context: Context): Room {
        return sharedRoom ?: LiveKit.create(context.applicationContext, overrides = LiveKitOverrides(
            audioOptions = AudioOptions(audioHandler = AudioSwitchHandler(context.applicationContext).apply {
                manageAudioFocus = false
                audioMode = AudioManager.MODE_NORMAL
                preferredDeviceList = listOf(AudioDevice.BluetoothHeadset::class.java, AudioDevice.WiredHeadset::class.java,
                    AudioDevice.Speakerphone::class.java, AudioDevice.Earpiece::class.java)
            })
        )).also { sharedRoom = it }
    }
    fun acknowledge(id: String): Boolean {
        if (pendingAlert.value?.id != id) return false
        pendingAlert.value = null
        return true
    }
}
