package cl.radioequipo.app

import android.content.Intent
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.os.Bundle
import android.text.Editable
import android.text.TextWatcher
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.*
import androidx.activity.ComponentActivity
import androidx.activity.result.contract.ActivityResultContracts
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import androidx.lifecycle.lifecycleScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.time.ZonedDateTime
import java.time.ZoneId
import java.time.format.DateTimeFormatter

class RosterActivity : ComponentActivity() {
    private val prefs by lazy { getSharedPreferences("benm_lista_local", MODE_PRIVATE) }
    private val rows = mutableListOf<RosterEntry>()
    private lateinit var table: LinearLayout
    private lateinit var verticalScroll: ScrollView
    private lateinit var status: TextView
    private lateinit var exportButton: Button
    private var pendingExport: String? = null
    private val saveExcel = registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { result ->
        val snapshot = pendingExport
        pendingExport = null
        val uri = result.data?.data
        if (result.resultCode != RESULT_OK || uri == null || snapshot == null) {
            exportButton.isEnabled = true
        } else lifecycleScope.launch {
            try {
                withContext(Dispatchers.IO) {
                    val bytes = RosterWorkbook.encode(RosterData.decode(snapshot))
                    val output = contentResolver.openOutputStream(uri, "wt") ?: error("No se pudo abrir el archivo")
                    output.use { it.write(bytes) }
                }
                Toast.makeText(this@RosterActivity, "Lista exportada a Excel", Toast.LENGTH_LONG).show()
            } catch (error: Exception) {
                if (error is kotlinx.coroutines.CancellationException) throw error
                Toast.makeText(this@RosterActivity, "No se pudo exportar: ${error.message}", Toast.LENGTH_LONG).show()
            } finally { exportButton.isEnabled = true }
        }
    }

    private fun dp(value: Int) = (value * resources.displayMetrics.density).toInt()
    private fun cellBackground() = GradientDrawable().apply {
        setColor(Color.rgb(17, 29, 43)); setStroke(dp(1).coerceAtLeast(1), Color.rgb(49, 69, 91))
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        pendingExport = savedInstanceState?.getString("pendingExport")
        val saved = prefs.getString("rows", null)
        if (saved != null) {
            runCatching { rows.addAll(RosterData.decode(saved)) }.onFailure {
                Toast.makeText(this, "No se pudo abrir la lista guardada", Toast.LENGTH_LONG).show()
            }
        }
        // Migrate the old blank template once, without dropping any recorded row.
        if (prefs.getInt("templateVersion", 0) < 18) {
            val lastData = rows.indexOfLast { it.usuario.isNotBlank() || it.tipo.isNotBlank() || it.sector.isNotBlank() }
            val keep = maxOf(20, lastData + 1)
            while (rows.size > keep) rows.removeAt(rows.lastIndex)
        }
        while (rows.size < 20) rows.add(RosterEntry())
        prefs.edit().putInt("templateVersion", 18).putString("rows", RosterData.encode(rows)).apply()

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(Color.rgb(10, 18, 28))
            setPadding(dp(12), dp(12), dp(12), dp(8))
        }
        ViewCompat.setOnApplyWindowInsetsListener(root) { view, insets ->
            val bars = insets.getInsets(WindowInsetsCompat.Type.systemBars() or WindowInsetsCompat.Type.ime())
            view.setPadding(dp(12) + bars.left, dp(12) + bars.top, dp(12) + bars.right, dp(8) + bars.bottom)
            insets
        }
        root.addView(TextView(this).apply {
            text = "LISTA"; textSize = 24f; setTextColor(Color.WHITE); setTypeface(typeface, Typeface.BOLD)
        })
        status = TextView(this).apply { setTextColor(Color.LTGRAY); textSize = 12f; setPadding(0, dp(6), 0, dp(8)) }
        root.addView(status)
        val actions = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        actions.addView(Button(this).apply {
            text = "AGREGAR FILA"; textSize = 12f
            setOnClickListener {
                val entry = RosterEntry(); rows.add(entry); addRow(entry, rows.size); persist()
                verticalScroll.post { verticalScroll.fullScroll(View.FOCUS_DOWN) }
            }
        }, LinearLayout.LayoutParams(0, dp(50), 1f))
        exportButton = Button(this).apply {
            text = "EXPORTAR A EXCEL"; textSize = 12f
            setOnClickListener {
                pendingExport = RosterData.encode(rows)
                isEnabled = false
                val stamp = ZonedDateTime.now(ZoneId.of("America/Santiago")).format(DateTimeFormatter.ofPattern("yyyy-MM-dd-HHmmss"))
                saveExcel.launch(Intent(Intent.ACTION_CREATE_DOCUMENT).apply {
                    addCategory(Intent.CATEGORY_OPENABLE)
                    type = RosterWorkbook.MIME
                    putExtra(Intent.EXTRA_TITLE, "BENM-lista-$stamp.xlsx")
                })
            }
        }
        actions.addView(exportButton, LinearLayout.LayoutParams(0, dp(50), 1f))
        root.addView(actions)
        root.addView(Button(this).apply {
            text = "LIMPIAR LISTA"; textSize = 12f
            setTextColor(Color.rgb(255, 170, 160))
            setOnClickListener {
                android.app.AlertDialog.Builder(this@RosterActivity)
                    .setTitle("Limpiar lista")
                    .setMessage("Se borrarán Usuario, Tipo y Sector de la lista de este teléfono. Si necesitas conservarlos, exporta a Excel antes de limpiar. Los archivos ya exportados se conservan.")
                    .setNegativeButton("CANCELAR", null)
                    .setPositiveButton("LIMPIAR") { _, _ -> clearList() }
                    .show()
            }
        }, LinearLayout.LayoutParams(-1, dp(48)))
        root.addView(TextView(this).apply {
            text = "Escribe en Usuario y toca Tipo o Sector para elegir. Desliza la tabla para ver las columnas."
            setTextColor(Color.LTGRAY); textSize = 12f; setPadding(0, dp(6), 0, dp(8))
        })
        val panel = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        val header = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        listOf("N.º", "Usuario", "Tipo", "Sector").forEachIndexed { index, title ->
            header.addView(TextView(this).apply {
                text = title; textSize = 16f; setTextColor(Color.WHITE); setTypeface(typeface, Typeface.BOLD)
                gravity = Gravity.CENTER_VERTICAL; setPadding(dp(10), 0, dp(6), 0)
                setBackgroundColor(Color.rgb(23, 54, 93))
            }, column(index, dp(44)))
        }
        panel.addView(header)
        table = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        verticalScroll = ScrollView(this).apply { addView(table) }
        panel.addView(verticalScroll, LinearLayout.LayoutParams(-1, 0, 1f))
        val horizontal = HorizontalScrollView(this).apply {
            isFillViewport = true
            addView(panel, ViewGroup.LayoutParams(dp(528), ViewGroup.LayoutParams.MATCH_PARENT))
        }
        root.addView(horizontal, LinearLayout.LayoutParams(-1, 0, 1f))
        root.addView(Button(this).apply { text = "VOLVER A RADIO"; setOnClickListener { finish() } })
        rows.forEachIndexed { index, row -> addRow(row, index + 1) }
        updateStatus()
        setContentView(root)
    }

    private fun column(index: Int, height: Int) = if (index == 0) LinearLayout.LayoutParams(dp(48), height)
        else LinearLayout.LayoutParams(0, height, when (index) { 1 -> 1.5f; 2 -> 1.15f; else -> 1f })

    private fun addRow(entry: RosterEntry, number: Int) {
        val line = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        line.addView(TextView(this).apply {
            text = number.toString(); textSize = 14f; gravity = Gravity.CENTER
            setTextColor(Color.LTGRAY); background = cellBackground()
            contentDescription = "Número $number"
        }, column(0, dp(56)))
        line.addView(EditText(this).apply {
            setText(entry.usuario); hint = "Escribir…"; textSize = 15f
            contentDescription = "Usuario, fila $number"
            setTextColor(Color.WHITE); setHintTextColor(Color.LTGRAY)
            setSingleLine(true)
            inputType = android.text.InputType.TYPE_CLASS_TEXT or android.text.InputType.TYPE_TEXT_FLAG_CAP_WORDS
            filters = arrayOf(android.text.InputFilter.LengthFilter(120))
            setPadding(dp(10), 0, dp(6), 0); background = cellBackground()
            addTextChangedListener(object : TextWatcher {
                override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {}
                override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) { entry.usuario = s.toString(); persist() }
                override fun afterTextChanged(s: Editable?) {}
            })
        }, column(1, dp(56)))
        line.addView(selector(RosterData.tipos, entry.tipo, "Tipo, fila $number", false) {
            if (entry.tipo != it) { entry.tipo = it; persist() }
        }, column(2, dp(56)))
        line.addView(selector(RosterData.sectores, entry.sector, "Sector, fila $number", true) {
            if (entry.sector != it) { entry.sector = it; persist() }
        }, column(3, dp(56)))
        table.addView(line)
    }

    private fun selector(options: List<String>, selected: String, description: String, sector: Boolean, changed: (String) -> Unit): Spinner {
        val adapter = object : ArrayAdapter<String>(this, android.R.layout.simple_spinner_item, options.map { it.ifBlank { "Elegir…" } }) {
            override fun getView(position: Int, convertView: View?, parent: ViewGroup): View {
                return (super.getView(position, convertView, parent) as TextView).apply {
                    text = "${getItem(position)} ▾"; textSize = 14f; gravity = Gravity.CENTER_VERTICAL
                    setPadding(dp(8), 0, dp(4), 0)
                    val fill = if (sector) when (options[position]) {
                        "Rojo" -> Color.rgb(250, 219, 216)
                        "Amarillo" -> Color.rgb(255, 242, 204)
                        "Verde" -> Color.rgb(226, 239, 218)
                        else -> Color.TRANSPARENT
                    } else Color.TRANSPARENT
                    setBackgroundColor(fill); setTextColor(if (fill == Color.TRANSPARENT) Color.WHITE else Color.BLACK)
                }
            }
            override fun getDropDownView(position: Int, convertView: View?, parent: ViewGroup): View {
                return (super.getDropDownView(position, convertView, parent) as TextView).apply {
                    textSize = 16f; setTextColor(Color.BLACK); setBackgroundColor(Color.WHITE)
                    setPadding(dp(12), dp(14), dp(12), dp(14))
                }
            }
        }.apply { setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item) }
        return Spinner(this).apply {
            contentDescription = description; background = cellBackground()
            this.adapter = adapter
            setSelection(options.indexOf(selected).coerceAtLeast(0), false)
            onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
                override fun onItemSelected(parent: AdapterView<*>?, view: View?, position: Int, id: Long) { changed(options[position]) }
                override fun onNothingSelected(parent: AdapterView<*>?) {}
            }
        }
    }

    private fun persist() {
        prefs.edit().putString("rows", RosterData.encode(rows)).apply()
        updateStatus()
    }

    private fun clearList() {
        rows.clear()
        repeat(20) { rows.add(RosterEntry()) }
        table.removeAllViews()
        rows.forEachIndexed { index, row -> addRow(row, index + 1) }
        persist()
        verticalScroll.isFocusableInTouchMode = true
        verticalScroll.requestFocus()
        getSystemService(android.view.inputmethod.InputMethodManager::class.java)
            ?.hideSoftInputFromWindow(table.windowToken, 0)
        verticalScroll.post { verticalScroll.scrollTo(0, 0) }
        Toast.makeText(this, "Lista limpia y guardada", Toast.LENGTH_SHORT).show()
    }

    private fun updateStatus() {
        val count = rows.count { it.usuario.isNotBlank() || it.tipo.isNotBlank() || it.sector.isNotBlank() }
        status.text = "Guardado en este teléfono · $count filas con datos"
    }

    override fun onSaveInstanceState(outState: Bundle) {
        outState.putString("pendingExport", pendingExport)
        super.onSaveInstanceState(outState)
    }
}
