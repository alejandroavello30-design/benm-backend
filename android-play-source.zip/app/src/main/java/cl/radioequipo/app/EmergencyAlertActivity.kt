package cl.radioequipo.app

import android.media.AudioAttributes
import android.media.Ringtone
import android.media.RingtoneManager
import android.os.Build
import android.os.Bundle
import android.os.VibrationEffect
import android.os.Vibrator
import android.os.VibratorManager
import android.view.Gravity
import android.view.WindowManager
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import androidx.activity.ComponentActivity
import androidx.core.content.ContextCompat

class EmergencyAlertActivity : ComponentActivity() {
    private var ringtone: Ringtone? = null
    private var vibrator: Vibrator? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        showOverLockScreen()

        val sender = intent.getStringExtra(EXTRA_SENDER).orEmpty().ifBlank { "Usuario" }
        val emergencyType = intent.getStringExtra(EXTRA_TYPE).orEmpty().ifBlank { "EMERGENCIA" }
        val message = intent.getStringExtra(EXTRA_MESSAGE).orEmpty().ifBlank { emergencyType }

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            setPadding(28, 28, 28, 28)
            setBackgroundResource(R.drawable.bg_alert)
        }

        val badge = TextView(this).apply {
            text = "🚨"
            textSize = 54f
            gravity = Gravity.CENTER
        }
        root.addView(badge, LinearLayout.LayoutParams(-1, -2))

        val title = TextView(this).apply {
            text = "¡$emergencyType!"
            textSize = 28f
            setTextColor(ContextCompat.getColor(context, android.R.color.white))
            gravity = Gravity.CENTER
            setTypeface(typeface, android.graphics.Typeface.BOLD)
        }
        root.addView(title, LinearLayout.LayoutParams(-1, -2))

        val who = TextView(this).apply {
            text = "La emergencia fue activada por:\n\n$sender"
            textSize = 19f
            setTextColor(0xFFFFD9DC.toInt())
            gravity = Gravity.CENTER
            setPadding(0, 24, 0, 24)
        }
        root.addView(who, LinearLayout.LayoutParams(-1, -2))

        val detail = TextView(this).apply {
            text = message
            textSize = 15f
            setTextColor(0xFFFFB8BE.toInt())
            gravity = Gravity.CENTER
        }
        root.addView(detail, LinearLayout.LayoutParams(-1, -2))

        val acknowledge = Button(this).apply {
            text = "RECONOCER ALERTA"
            textSize = 16f
            setTextColor(ContextCompat.getColor(context, android.R.color.white))
            setTypeface(typeface, android.graphics.Typeface.BOLD)
            background = ContextCompat.getDrawable(context, R.drawable.bg_alert_button)
            setOnClickListener { finishAlert() }
        }
        val buttonParams = LinearLayout.LayoutParams(-1, 58).apply { topMargin = 30 }
        root.addView(acknowledge, buttonParams)

        setContentView(root)
        startAlertSound()
        startVibration()
    }

    private fun showOverLockScreen() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O_MR1) {
            setShowWhenLocked(true)
            setTurnScreenOn(true)
        } else {
            @Suppress("DEPRECATION")
            window.addFlags(
                WindowManager.LayoutParams.FLAG_SHOW_WHEN_LOCKED or
                    WindowManager.LayoutParams.FLAG_TURN_SCREEN_ON
            )
        }
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
    }

    private fun startAlertSound() {
        val uri = RingtoneManager.getDefaultUri(RingtoneManager.TYPE_ALARM)
            ?: RingtoneManager.getDefaultUri(RingtoneManager.TYPE_NOTIFICATION)
        runCatching {
            ringtone = RingtoneManager.getRingtone(this, uri)
            ringtone?.audioAttributes = AudioAttributes.Builder()
                .setUsage(AudioAttributes.USAGE_ALARM)
                .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION)
                .build()
            ringtone?.play()
        }
    }

    private fun startVibration() {
        vibrator = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
            getSystemService(VibratorManager::class.java).defaultVibrator
        } else {
            @Suppress("DEPRECATION")
            getSystemService(VIBRATOR_SERVICE) as Vibrator
        }
        val pattern = longArrayOf(0, 500, 250, 500, 250, 900)
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            vibrator?.vibrate(VibrationEffect.createWaveform(pattern, 0))
        } else {
            @Suppress("DEPRECATION")
            vibrator?.vibrate(pattern, 0)
        }
    }

    override fun onNewIntent(intent: android.content.Intent?) {
        super.onNewIntent(intent)
        if (intent != null) { setIntent(intent); recreate() }
    }

    private fun finishAlert() {
        if (RadioSession.acknowledge(intent.getStringExtra("alert_id").orEmpty())) {
            getSystemService(android.app.NotificationManager::class.java).cancel(2202)
        }
        ringtone?.stop()
        vibrator?.cancel()
        finish()
    }

    override fun onDestroy() {
        ringtone?.stop()
        vibrator?.cancel()
        super.onDestroy()
    }

    companion object {
        const val EXTRA_SENDER = "sender"
        const val EXTRA_TYPE = "emergency_type"
        const val EXTRA_MESSAGE = "message"
    }
}
