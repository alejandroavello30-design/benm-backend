package cl.radioequipo.app

import org.json.JSONArray
import java.time.Instant
import java.time.ZoneId
import java.time.format.DateTimeFormatter

object AttendanceCsv {
    fun encode(date: String, records: JSONArray): String {
        fun cell(value: String): String {
            // Prevent spreadsheet formula execution when opening names in Excel.
            val safe = if (value.trimStart().firstOrNull() in listOf('=', '+', '-', '@', '\t', '\r', '\n')) "'$value" else value
            return "\"${safe.replace("\"", "\"\"")}\""
        }
        val lines = mutableListOf("Fecha;Nombre;Estado;Fecha y hora del registro (Chile);Registrado por;Tipo de registro")
        for (index in 0 until records.length()) {
            val row = records.getJSONObject(index)
            val time = Instant.parse(row.getString("markedAt")).atZone(ZoneId.of("America/Santiago"))
                .format(DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss XXX"))
            lines.add(listOf(date, row.getString("name"), "Presente", time, row.getString("markedBy"),
                if (row.optString("source") == "admin") "Administrador" else "Miembro").joinToString(";") { cell(it) })
        }
        return "\uFEFF" + lines.joinToString("\r\n") + "\r\n"
    }
}
