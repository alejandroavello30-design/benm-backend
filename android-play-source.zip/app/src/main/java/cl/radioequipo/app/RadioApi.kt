package cl.radioequipo.app

import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder

data class EmergencyMessage(val id: String, val sender: String, val type: String, val message: String) {
    fun payload() = JSONObject().put("type", "emergency").put("id", id).put("sender", sender)
        .put("emergencyType", type).put("message", message).toString().toByteArray(Charsets.UTF_8)
    companion object {
        fun fromData(data: ByteArray, fallbackSender: String): EmergencyMessage? = runCatching {
            val json = JSONObject(String(data, Charsets.UTF_8))
            if (json.optString("type") != "emergency" || json.optString("id").isBlank()) return null
            val type = json.optString("emergencyType").ifBlank { "EMERGENCIA" }
            EmergencyMessage(json.getString("id"), json.optString("sender").ifBlank { fallbackSender }, type,
                json.optString("message").ifBlank { type })
        }.getOrNull()
    }
}
class RadioApiException(val status: Int, message: String) : IllegalStateException(message)
data class RadioCredentials(val url: String, val token: String, val role: String, val attendanceToken: String)

object RadioApi {
    private fun get(url: String): JSONObject {
        val connection = URL(url).openConnection() as HttpURLConnection
        try {
            connection.connectTimeout = 10000; connection.readTimeout = 15000
            connection.setRequestProperty("Accept", "application/json")
            val status = connection.responseCode
            val text = (if (status in 200..299) connection.inputStream else connection.errorStream)?.bufferedReader()?.use { it.readText() }.orEmpty()
            val json = runCatching { JSONObject(text) }.getOrElse { JSONObject() }
            if (status !in 200..299) throw RadioApiException(status, json.optString("error").ifBlank { "No se pudo conectar ($status)" })
            return json
        } finally { connection.disconnect() }
    }
    fun token(backend: String, name: String, code: String, channel: String, recover: Boolean): RadioCredentials {
        fun enc(value: String) = URLEncoder.encode(value, "UTF-8")
        val json = get("$backend/token?name=${enc(name)}&accessCode=${enc(code)}&room=${enc(channel)}&recoverSession=$recover")
        return RadioCredentials(json.getString("serverUrl"), json.getString("participantToken"), json.optString("role", "member"), json.optString("attendanceToken"))
    }
    fun emergency(backend: String, channel: String): EmergencyMessage? {
        val json = get("$backend/emergency?room=${URLEncoder.encode(channel, "UTF-8")}")
        val alert = json.optJSONObject("alert") ?: return null
        val text = alert.getString("message")
        val partial = text.startsWith("EVACUACIÓN PARCIAL |")
        return EmergencyMessage(alert.getString("id"), alert.getString("sender"), if (partial) "EVACUACIÓN PARCIAL" else text,
            if (partial) text.substringAfter('|').trim() else text)
    }
}
