package cl.radioequipo.app

import org.json.JSONArray
import org.json.JSONObject

data class RosterEntry(var usuario: String = "", var tipo: String = "", var sector: String = "")

object RosterData {
    val tipos = listOf("", "Funcionario", "Paciente")
    val sectores = listOf("", "Rojo", "Amarillo", "Verde")

    fun encode(rows: List<RosterEntry>): String = JSONArray().apply {
        rows.forEach { row -> put(JSONObject().put("usuario", row.usuario).put("tipo", row.tipo).put("sector", row.sector)) }
    }.toString()

    fun decode(text: String): MutableList<RosterEntry> {
        val array = JSONArray(text)
        return MutableList(array.length()) { index ->
            val item = array.getJSONObject(index)
            RosterEntry(item.optString("usuario"), item.optString("tipo").takeIf { it in tipos }.orEmpty(),
                item.optString("sector").takeIf { it in sectores }.orEmpty())
        }
    }
}
