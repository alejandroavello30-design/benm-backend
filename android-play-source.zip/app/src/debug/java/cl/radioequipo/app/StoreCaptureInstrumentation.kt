package cl.radioequipo.app

import android.app.Activity
import android.app.Instrumentation
import android.content.Intent
import android.graphics.Bitmap
import android.os.Bundle
import android.os.SystemClock
import java.io.File

/** Debug-only device check and genuine store captures. Never included in release. */
class StoreCaptureInstrumentation : Instrumentation() {
    override fun onCreate(arguments: Bundle?) { super.onCreate(arguments); start() }
    override fun onStart() {
        try {
            val directory = File(targetContext.filesDir, "store-captures").apply { mkdirs() }
            listOf("MainActivity" to "01-acceso", "RosterActivity" to "02-lista", "PrivacyActivity" to "03-privacidad").forEach { (screen, name) ->
                val activity = startActivitySync(Intent().setClassName(targetContext.packageName, "cl.radioequipo.app.$screen").addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
                waitForIdleSync()
                SystemClock.sleep(1500)
                val screenshot = uiAutomation.takeScreenshot() ?: error("No se pudo capturar $screen")
                File(directory, "$name.png").outputStream().use { screenshot.compress(Bitmap.CompressFormat.PNG, 100, it) }
                screenshot.recycle()
                runOnMainSync { activity.finish() }
                waitForIdleSync()
            }
            finish(Activity.RESULT_OK, Bundle().apply { putString("stream", "BENM API 36: acceso, lista y privacidad abiertos y capturados correctamente.\n") })
        } catch (error: Throwable) {
            finish(Activity.RESULT_CANCELED, Bundle().apply { putString("stream", error.stackTraceToString()) })
        }
    }
}
