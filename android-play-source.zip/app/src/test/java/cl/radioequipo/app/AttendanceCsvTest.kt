package cl.radioequipo.app

import org.json.JSONArray
import org.json.JSONObject
import org.junit.Assert.*
import org.junit.Test

class AttendanceCsvTest {
    @Test fun preservesAccentsEscapesCellsAndUsesChileTime() {
        val rows = JSONArray().put(JSONObject()
            .put("name", "José; \"Pérez\"")
            .put("markedAt", "2026-11-04T02:30:00Z")
            .put("markedBy", "=HYPERLINK(\"bad\")")
            .put("source", "admin"))
        val csv = AttendanceCsv.encode("2026-11-03", rows)
        assertTrue(csv.startsWith("\uFEFFFecha;Nombre;"))
        assertTrue(csv.contains("\"José; \"\"Pérez\"\"\""))
        assertTrue(csv.contains("2026-11-03 23:30:00 -03:00"))
        assertTrue(csv.contains("\"'=HYPERLINK(\"\"bad\"\")\""))
        assertTrue(csv.endsWith("\r\n"))
    }
    @Test fun exportsEachRecordWithItsAuditFields() {
        val rows = JSONArray()
        for (name in listOf("Ana", "Luis")) rows.put(JSONObject()
            .put("name", name).put("markedAt", "2026-11-03T15:00:00Z")
            .put("markedBy", name).put("source", "member"))
        val lines = AttendanceCsv.encode("2026-11-03", rows).trimEnd().split("\r\n")
        assertEquals(3, lines.size)
        assertTrue(lines[1].contains("\"Presente\""))
        assertTrue(lines[2].endsWith("\"Luis\";\"Miembro\""))
    }
}
