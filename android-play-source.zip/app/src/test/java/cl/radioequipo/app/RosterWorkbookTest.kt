package cl.radioequipo.app

import org.junit.Assert.*
import org.junit.Test
import java.io.ByteArrayInputStream
import java.io.File
import java.util.zip.ZipInputStream
import javax.xml.parsers.DocumentBuilderFactory

class RosterWorkbookTest {
    private fun unpack(bytes: ByteArray): Map<String, ByteArray> {
        val parts = linkedMapOf<String, ByteArray>()
        ZipInputStream(ByteArrayInputStream(bytes)).use { zip ->
            while (true) { val entry = zip.nextEntry ?: break; parts[entry.name] = zip.readBytes() }
        }
        return parts
    }
    private fun document(bytes: ByteArray) = DocumentBuilderFactory.newInstance().apply { isNamespaceAware = true }
        .newDocumentBuilder().parse(ByteArrayInputStream(bytes))

    @Test fun createsRealWorkbookWithExactColumnsDropdownsAndLiteralUserText() {
        val entries = listOf(
            RosterEntry("José & María <Equipo>", "Funcionario", "Rojo"), RosterEntry(),
            RosterEntry("=1+1", "Paciente", "Amarillo"),
            RosterEntry("Ana", "Paciente", "Verde")
        )
        val bytes = RosterWorkbook.encode(entries)
        val parts = unpack(bytes)
        assertEquals(6, parts.size)
        parts.values.forEach { document(it) } // Every XML part is well formed.
        val sheet = document(parts.getValue("xl/worksheets/sheet1.xml"))
        val ns = "http://schemas.openxmlformats.org/spreadsheetml/2006/main"
        val cells = sheet.getElementsByTagNameNS(ns, "c")
        assertEquals(16, cells.length) // Four columns, header and three filled records.
        assertEquals("N.º", cells.item(0).textContent)
        assertEquals("Usuario", cells.item(1).textContent)
        assertEquals("Tipo", cells.item(2).textContent)
        assertEquals("Sector", cells.item(3).textContent)
        assertEquals("1", cells.item(4).textContent)
        assertEquals("José & María <Equipo>", cells.item(5).textContent)
        assertEquals("3", cells.item(8).textContent) // Preserve the on-screen number across blank rows.
        assertEquals("=1+1", cells.item(9).textContent)
        assertEquals("4", cells.item(12).textContent)
        assertEquals(0, sheet.getElementsByTagNameNS(ns, "f").length)
        assertEquals(2, sheet.getElementsByTagNameNS(ns, "dataValidation").length)
        val formulas = sheet.getElementsByTagNameNS(ns, "formula1")
        assertEquals("\"Funcionario,Paciente\"", formulas.item(0).textContent)
        assertEquals("\"Rojo,Amarillo,Verde\"", formulas.item(1).textContent)
        val artifact = File("build/outputs/roster-validation.xlsx")
        artifact.parentFile?.mkdirs(); artifact.writeBytes(bytes)
    }

    @Test fun blankListExportsTheEditable20RowTemplateAndDraftsArePreserved() {
        val ns = "http://schemas.openxmlformats.org/spreadsheetml/2006/main"
        val blank = document(unpack(RosterWorkbook.encode(emptyList())).getValue("xl/worksheets/sheet1.xml"))
        assertEquals(21, blank.getElementsByTagNameNS(ns, "row").length)
        assertEquals("20", blank.getElementsByTagNameNS(ns, "c").item(80).textContent)
        val draft = document(unpack(RosterWorkbook.encode(listOf(RosterEntry("Solo nombre")))).getValue("xl/worksheets/sheet1.xml"))
        assertEquals(2, draft.getElementsByTagNameNS(ns, "row").length)
        assertEquals("1", draft.getElementsByTagNameNS(ns, "c").item(4).textContent)
        assertEquals("Solo nombre", draft.getElementsByTagNameNS(ns, "c").item(5).textContent)
    }

    @Test fun savedTableRestoresNamesChoicesAndBlankRows() {
        val rows = listOf(RosterEntry("María \"Pérez\"", "Funcionario", "Rojo"), RosterEntry(), RosterEntry("Juan", "Paciente", "Verde"))
        assertEquals(rows, RosterData.decode(RosterData.encode(rows)))
        assertEquals("", RosterData.decode("[{\"usuario\":\"Ana\",\"tipo\":\"Otro\",\"sector\":\"Azul\"}]")[0].tipo)
    }
}
