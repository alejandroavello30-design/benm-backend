package cl.radioequipo.app

import org.junit.Assert.*
import org.junit.Test

class AlertLedgerTest {
    @Test fun dataAndPollingDeliverOneNotificationAndOwnAlertsStaySilentAfterRestart() {
        val ledger = AlertLedger()
        assertTrue(ledger.accept("event-1", "Ana", "Luis"))
        assertFalse(ledger.accept("event-1", "Ana", "Luis"))
        assertFalse(ledger.accept("own-event", " LUIS ", "Luis"))
        val restarted = AlertLedger(ledger.snapshot())
        assertFalse(restarted.accept("event-1", "Ana", "Luis"))
        assertFalse(restarted.accept("own-event", "Luis", "Otra persona"))
        assertTrue(restarted.accept("new-event", "Ana", "Luis"))
        assertFalse(restarted.accept("", "Ana", "Luis"))
    }

    @Test fun baselineDoesNotReplayOldEmergencyAndHistoryStaysBounded() {
        val ledger = AlertLedger()
        ledger.seed("old-event")
        assertFalse(ledger.accept("old-event", "Ana", "Luis"))
        repeat(200) { ledger.accept("id-$it", "Ana", "Luis") }
        assertEquals(128, ledger.snapshot().size)
        assertEquals("id-199", ledger.snapshot().last())
    }

    @Test fun parsesLiveAlertWithoutLosingEvacuationLocationAndRejectsInvalidPayload() {
        val alert = EmergencyMessage.fromData("""{"type":"emergency","id":"a1","sender":"Ana","emergencyType":"EVACUACIÓN PARCIAL","message":"Lugar: Sector Rojo"}""".toByteArray(), "Usuario")!!
        assertEquals("Sector Rojo", alert.message.substringAfter("Lugar: "))
        assertEquals(alert, EmergencyMessage.fromData(alert.payload(), "Otra persona"))
        assertNull(EmergencyMessage.fromData("{}".toByteArray(), "Usuario"))
        assertNull(EmergencyMessage.fromData("not-json".toByteArray(), "Usuario"))
    }
}
