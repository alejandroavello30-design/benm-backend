import java.util.Properties

plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android {
    namespace = "cl.radioequipo.app"
    compileSdk = 36

    defaultConfig {
        applicationId = "cl.radioequipo.app"
        minSdk = 26
        targetSdk = 36
        versionCode = 22
        versionName = "0.3.22"
    }

    val uploadProperties = Properties()
    val uploadPropertiesFile = rootProject.file("upload-signing.properties")
    if (uploadPropertiesFile.exists()) uploadPropertiesFile.inputStream().use { uploadProperties.load(it) }
    signingConfigs {
        if (uploadPropertiesFile.exists()) create("upload") {
            storeFile = file(uploadProperties.getProperty("storeFile"))
            storePassword = uploadProperties.getProperty("storePassword")
            keyAlias = uploadProperties.getProperty("keyAlias")
            keyPassword = uploadProperties.getProperty("keyPassword")
        }
    }
    buildTypes {
        getByName("release") {
            isDebuggable = false
            isMinifyEnabled = false
            if (uploadPropertiesFile.exists()) signingConfig = signingConfigs.getByName("upload")
        }
    }

    buildFeatures {
        buildConfig = true
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }

    kotlinOptions {
        jvmTarget = "17"
    }
}

dependencies {
    testImplementation("junit:junit:4.13.2")
    testImplementation("org.json:json:20240303")
    implementation("androidx.core:core-ktx:1.15.0")
    implementation("androidx.appcompat:appcompat:1.7.0")
    implementation("com.google.android.material:material:1.12.0")
    implementation("androidx.lifecycle:lifecycle-runtime-ktx:2.8.7")
    implementation("io.livekit:livekit-android:2.29.0")
}
