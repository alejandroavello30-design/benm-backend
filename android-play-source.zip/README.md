# BENM 0.3.11

Actualización sobre la versión 0.3.9.

## Cambios
- PTT adaptativo al tamaño de pantalla.
- BENM desactiva el micrófono fuera de PTT.
- BENM ya no solicita audio focus al conectarse y usa modo de audio NORMAL para no bloquear TikTok/YouTube/WhatsApp mientras la radio está conectada.
- Instructivos centralizados en el backend.
- Botones de INSTRUCTIVOS con estilo explícito y visibles en modo administrador/miembro.
- Ajuste de barras de estado/navegación para evitar que los controles queden tapados en Android moderno.
- Rol `admin`: puede subir/eliminar.
- Rol `member`: solo puede listar/abrir.
- Evacuación Parcial conserva el campo de lugar.
- Backend mantiene Render + LiveKit Cloud.

## Configuración de Render

Agregar esta variable:
```text
ADMIN_ACCESS_CODE=EL-CODIGO-PRIVADO-QUE-TU-ELIJAS
```

No poner este código dentro del APK.

Opcional para almacenamiento persistente:
```text
FILES_DIR=/var/data/benm-files
```
Usa esa ruta solamente si el servicio de Render tiene un almacenamiento persistente montado. Sin almacenamiento persistente, los archivos del servidor pueden perderse después de ciertos reinicios/redeploys.

Mantener las variables actuales:
```text
TEAM_ACCESS_CODE=CAMBIAR-ESTE-CODIGO
LIVEKIT_URL=wss://benm-28cmuz17.livekit.cloud
LIVEKIT_API_KEY=...
LIVEKIT_API_SECRET=...
ROOM_MAX_PARTICIPANTS=25
```

## Uso de roles
- Código normal del equipo -> miembro.
- `ADMIN_ACCESS_CODE` -> administrador.

El administrador verá `SUBIR ARCHIVO` y `ELIMINAR`.
Los miembros solo verán `VER`.

## Compilación
Abrir el proyecto en Android Studio y ejecutar:
Build -> Clean Project
Build -> Rebuild Project

No se incluye una afirmación de APK compilado en este paquete; el entorno de esta sesión no pudo descargar Gradle desde Internet.
