# BENM Android 0.3.21

## Instalación

Instalar BENM-Android-0.3.21.apk sobre la versión actual. Se conserva la misma aplicación y firma. Abrir BENM, permitir notificaciones y conectar con el nombre y código habituales. Si una conexión anterior todavía ocupa el nombre, usar Recuperar sesión.

## Radio y avisos en segundo plano

La conexión LiveKit, el audio y la recepción de alertas pertenecen al servicio de radio. La pantalla principal ya no cierra esa conexión al destruirse. Al bloquear el teléfono, cambiar de app o quitar BENM de recientes, el servicio puede continuar con la notificación permanente de radio y avisos. Abrir BENM recupera la sesión existente, sin conectarse como otro participante.

El micrófono solo se habilita al mantener HABLAR con la pantalla de radio visible. Se deshabilita al soltarlo, salir de la pantalla o quitar BENM de recientes. El servicio se inicia como reproducción de audio; añade el tipo de micrófono al transmitir en las versiones que lo soportan. Conserva el modo de audio NORMAL y no toma el foco multimedia de otras aplicaciones.

Los eventos LiveKit son el camino principal para las alertas; el servicio también consulta el último aviso del backend como respaldo. Se guardan los identificadores recientes para no notificar dos veces el mismo aviso. Al iniciar una nueva sesión manual se toma como referencia el último aviso anterior para no repetirlo como nuevo. Hay reconexión por pérdida de red y recuperación de sesión si Android reinicia un servicio previamente activo. Una sesión sustituida por otro teléfono o retirada por el servidor se detiene y no intenta recuperar continuamente ese nombre.

El aviso usa una notificación de alta prioridad, con sonido/vibración según los permisos y ajustes de Android. Tocar la notificación abre la pantalla de alerta para reconocerla. La app no fuerza una pantalla por encima de otras aplicaciones. No se integra Firebase Cloud Messaging ni una cola garantizada de avisos históricos: el funcionamiento depende de que el servicio y la conexión permanezcan operativos.

Para la pantalla apagada, permitir notificaciones de BENM y configurar Batería sin restricciones, si el teléfono ofrece esa opción. Algunos fabricantes también tienen un permiso de inicio automático. Se consume batería y datos mientras la radio está conectada. La app avisa al conectar si las notificaciones de emergencias están deshabilitadas.

Forzar detención desde Ajustes, detener BENM desde el administrador de Android, apagar el teléfono, perder Internet o restringir la batería pueden detener o retrasar los avisos. No se promete recepción después de una detención forzada. Tras reiniciar el teléfono, abrir BENM para recuperar la sesión. La recuperación automática está sujeta al permiso de Android para reiniciar el servicio; no se añaden alarmas para eludir una parada del usuario.

## Confirmaciones de sesión

DESCONECTAR solicita confirmación. CANCELAR mantiene la radio. Confirmar detiene la radio y los avisos y conserva nombre/código.

SALIR / CAMBIAR USUARIO también solicita confirmación. Confirmar detiene radio y avisos y borra el nombre y el código guardados. Las listas y los Excel ya exportados se conservan.

DESCONECTAR desde la notificación permanente abre BENM y pide la misma confirmación. Cerrar la pantalla o quitar la app de recientes no equivale a confirmar una desconexión.

## Asistencia compartida

Todos los miembros autenticados pueden consultar el listado de asistencia del equipo y el historial por fecha. ACTUALIZAR LISTADO muestra las nuevas marcaciones. Cada miembro marca únicamente su propia asistencia de hoy; el coordinador/administrador puede marcar por otros y registrar fechas anteriores. La exportación de asistencia sigue disponible para el administrador como CSV para Excel.

Los registros son una vez por nombre y día, con fecha de Chile, hora real de marcación y quién la realizó. El acceso conserva el código compartido de BENM: usar nombres completos y únicos. No hay padrón para calcular ausentes ni verificación de identidad o ubicación. Las sesiones de asistencia duran 24 horas; si caducan, desconectar y reconectar para renovarlas.

La visibilidad del equipo ya está publicada en el servidor existente de Render:
https://github.com/alejandroavello30-design/benm-backend/commit/566974d505fe0735f397e6acc87dc63ffa134dbb

Versión de backend: 0.3.15-server.4. /health respondió attendanceTeamVisible=true, attendanceReady=true y attendanceStorageCheck=passed al verificar el despliegue. La asistencia se conserva en Cloudinary como recursos autenticados, separados de los instructivos. No hace falta agregar un disco de Render. No cambiar el adaptador a disco sin migrar los registros.

## Lista local y Excel

LISTA reemplaza la pestaña Coordinación. Tiene N.º automático, Usuario editable, Tipo (Funcionario/Paciente) y Sector (Rojo/Amarillo/Verde). Empieza con 20 filas y AGREGAR FILA permite ampliar la planilla. La actualización conserva todas las filas con datos.

Los cambios de la lista se guardan automáticamente en ese teléfono. No se comparten con otros teléfonos ni se envían al backend. Se conservan al cambiar de usuario en el mismo dispositivo.

EXPORTAR A EXCEL genera un .xlsx con N.º, Usuario, Tipo y Sector. Conserva encabezado fijo, filtros, desplegables y colores. Los correlativos se guardan como números reales y coinciden con los números de la app. Se omiten las filas completamente vacías, por lo que puede haber saltos si dejaste filas vacías intermedias. Una lista vacía exporta una plantilla de 20 filas numeradas. Se pueden unir manualmente los archivos de varios teléfonos.

LIMPIAR LISTA pide confirmación, borra su contenido local y guarda 20 filas vacías desde el número 1. Los archivos exportados, el login y la asistencia compartida no se borran.

## Validación

- APK 0.3.21 compilado y firmado con el certificado anterior.
- Ocho pruebas Android aprobadas: tres de recepción/deduplicación de alertas, tres de lista/XLSX y dos de exportación CSV de asistencia.
- Lint Android completado sin errores; conserva advertencias de código y recursos existentes.
- Seis pruebas del backend aprobadas, incluidas visibilidad para miembros, restricción de marcaciones ajenas y persistencia.
- El XLSX numerado se había abierto y validado con openpyxl; el código de exportación se conserva y sus pruebas pasaron de nuevo.

No hay teléfono ni emulador conectado. Falta verificar el ciclo real del servicio y las notificaciones en los dispositivos del equipo. Prueba sugerida con dos teléfonos y nombres distintos: conectar ambos; en el receptor bloquear la pantalla o quitar BENM de recientes; enviar una alerta desde el otro y comprobar notificación/sonido y reconocimiento al tocarla. Reabrir BENM y comprobar que conserva la misma sesión. Probar CANCELAR y confirmar en Desconectar/Salir, y comprobar que después de desconectar no sigue recibiendo alertas. Verificar también que el micrófono se apaga al salir de la pantalla durante PTT.

Referencias de Android:
- https://developer.android.com/reference/android/app/Service
- https://developer.android.com/develop/background-work/services/fgs/service-types
- https://developer.android.com/develop/background-work/services/fgs/handle-user-stopping
- https://developer.android.com/training/monitoring-device-state/doze-standby
