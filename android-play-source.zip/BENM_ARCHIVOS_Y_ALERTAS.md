# BENM — correcciones de instructivos y alertas

## 1. Instructivos / Archivos (404)

La aplicación ya contiene el cliente para `/files`, pero el servidor de Render que está actualmente publicado debe tener también los endpoints de archivos incluidos en `server/server.js`.

En Render configura estas variables (sin poner secretos en la APK):

- `TEAM_ACCESS_CODE` = código del equipo
- `ADMIN_ACCESS_CODE` = código privado del administrador
- `FILES_DIR` = `/var/data/benm-files` si el servicio tiene Persistent Disk

El backend incluido en esta versión implementa:

- `GET /files` — lista para miembros y administrador
- `GET /files/:name` — abrir/descargar
- `POST /files` — solo administrador
- `DELETE /files/:name` — solo administrador

**Importante:** Render necesita desplegar este `server/server.js`. El 404 de la captura significa que la aplicación está llegando a un backend que todavía no tiene esos endpoints.

Para conservar los archivos después de un redeploy/reinicio, usa un Persistent Disk de Render y deja `FILES_DIR=/var/data/benm-files`.

## 2. Alertas que vuelven a aparecer

Ahora el reconocimiento de una alerta se registra por usuario:

- Al pulsar `RECONOCER ALERTA`, BENM envía `POST /emergency/ack`.
- El backend registra qué usuario reconoció esa alerta.
- Al iniciar sesión nuevamente, `GET /emergency` ya no devuelve esa alerta para ese usuario.
- Otro integrante que aún no la haya reconocido sí puede recibirla.
- El reconocimiento local también se guarda por nombre de usuario, evitando que un usuario herede el reconocimiento de otro en el mismo teléfono.

Los endpoints nuevos son:

- `GET /emergency?room=general&name=Nombre`
- `POST /emergency/ack`

No se debe colocar `ADMIN_ACCESS_CODE`, `LIVEKIT_API_KEY` ni `LIVEKIT_API_SECRET` dentro de la APK o GitHub.
