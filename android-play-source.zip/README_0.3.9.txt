BENM 0.3.9

Cambios:
- Nuevo botón INSTRUCTIVOS Y ARCHIVOS.
- Selector para subir archivos al almacenamiento privado de BENM.
- Visor interno para PDF (primera página), imágenes y archivos de texto comunes.
- Eliminación de archivos desde el módulo de instructivos.
- Nueva emergencia EVACUACIÓN PARCIAL.
- Al seleccionar EVACUACIÓN PARCIAL se solicita el lugar de la evacuación.
- La ubicación escrita viaja en la alerta y aparece en la alerta visual/notificación.
- Ajuste de liberación del micrófono al terminar PTT para facilitar el uso simultáneo con otras apps como WhatsApp.
- Versión 0.3.9 / versionCode 9.

Importante:
- No se modificó el backend de Render ni la URL de LiveKit Cloud.
- Los instructivos de esta primera versión se guardan localmente en cada teléfono. La sincronización de archivos para todo el equipo puede agregarse después.
- El proyecto fue validado en XML. La compilación completa no pudo ejecutarse en este entorno porque Gradle necesita descargar su distribución desde Internet.
