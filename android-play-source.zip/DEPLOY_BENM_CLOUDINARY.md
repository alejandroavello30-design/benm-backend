# BENM — archivos sin Persistent Disk de Render

Esta versión usa Cloudinary como almacenamiento permanente para Instructivos y Archivos. Render Free no necesita Persistent Disk.

## 1. Crear cuenta Cloudinary

Crea una cuenta gratuita en https://cloudinary.com/

En el Dashboard/Settings/API Keys obtén:
- Cloud name
- API Key
- API Secret

**Nunca pongas API Secret en la APK ni en GitHub.** Solo va en Render.

## 2. Variables en Render

En `benm-backend` → Environment agrega:

```text
ADMIN_ACCESS_CODE=TU_CODIGO_ADMIN
CLOUDINARY_CLOUD_NAME=TU_CLOUD_NAME
CLOUDINARY_API_KEY=TU_API_KEY
CLOUDINARY_API_SECRET=TU_API_SECRET
```

No agregues `FILES_DIR` ni Disk.

## 3. Backend

Sube a GitHub los cambios de `server/`. Render seguirá usando:

```text
Build Command: npm install
Start Command: node server.js
```

`npm install` instalará `cloudinary` desde `package.json`.

## 4. Qué hace BENM

- Administrador: puede subir y eliminar.
- Integrante: solo puede ver/abrir.
- Los archivos se etiquetan como `benm_files` en Cloudinary.
- Render no guarda los archivos en disco.
- El backend devuelve identificadores seguros y redirige la descarga a Cloudinary.

## 5. Límite

Esta implementación limita cada subida a 10 MB porque el plan gratuito de Cloudinary tiene un límite de 10 MB para archivos raw. Videos pueden manejarse de otra forma si después necesitamos archivos mayores.

## 6. Prueba

Después del deploy, abre:

`https://benm-backend.onrender.com/health`

Debe aparecer:

```json
{
  "ok": true,
  "files": true,
  "cloudinary": true
}
```

Luego entra a BENM con el código de administrador y abre **INSTRUCTIVOS Y ARCHIVOS**.
